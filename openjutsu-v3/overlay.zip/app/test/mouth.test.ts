import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";
import { pruneSimple, type ApiGraph } from "../lib/simple.ts";
import { pruneFace } from "../lib/face.ts";
import { applyModel, DEFAULT_MODEL, SMALL_ENCODER } from "../lib/model.ts";

const load = (mode: string): ApiGraph => JSON.parse(readFileSync(new URL(`../workflows/${mode}.api.json`, import.meta.url), "utf8"));
const settings = {role: "", resolution: "480p" as const, motion: 512 as const, hatFix: false, noLipSync: false,
                  margin: "normal" as const, target: "person", seed: 42, clipSeconds: 6};

function acyclic(graph: ApiGraph) {
  const visited = new Set<string>(), visiting = new Set<string>();
  function visit(id: string) {
    if (visited.has(id)) return;
    assert.ok(!visiting.has(id), "Cycle at " + id);
    visiting.add(id);
    for (const value of Object.values(graph[id].inputs)) {
      if (Array.isArray(value) && value.length === 2 && typeof value[0] === "string" && typeof value[1] === "number") {
        assert.ok(graph[value[0]], "Missing node " + value[0]); visit(value[0]);
      }
    }
    visiting.delete(id); visited.add(id);
  }
  for (const id of Object.keys(graph)) visit(id);
}

test("Simple protects source pixels before overlap trim, save and carry, and excludes the mouth from inpainting", () => {
  const graph = pruneSimple(load("simple"), {...settings, preserveMouth: true});
  assert.deepEqual(graph.keep_source_mouth.inputs.source, ["31", 0]);
  assert.deepEqual(graph.keep_source_mouth.inputs.generated, ["61", 0]);
  assert.deepEqual(graph["63"].inputs.images, ["keep_source_mouth", 0]);
  assert.deepEqual(graph["55"].inputs.mask, ["keep_source_mouth_exclude", 0]);
  assert.deepEqual(graph.keep_source_mouth_exclude.inputs.editable_mask, ["42", 0]);
  assert.equal(graph.mouth_run_name.inputs.string_b, "_mouthprotected1");
  assert.equal(graph["11"].inputs.seed, 42);
  applyModel(graph, {...DEFAULT_MODEL, textEncoder: SMALL_ENCODER, cacheMode: "v3"});
  assert.equal(graph.keep_source_mouth_track.class_type, "OpenJutsu3VideoTrackCached");
  assert.equal(graph["16"].inputs.strength_model, 1);
  acyclic(graph);
});

test("Disabling protection restores the previous Simple graph", () => {
  assert.deepEqual(pruneSimple(load("simple"), {...settings, preserveMouth: false}), pruneSimple(load("simple"), settings));
});

test("Face protection composites after stitching and preserves all source-frame indices", () => {
  for (const style of ["photo", "mouth"] as const) {
    const graph = pruneFace(load("face"), {style, seed: 0, chunkSeconds: 6.5, preserveMouth: true});
    const stitch = Object.entries(graph).find(([, n]) => n.class_type === "H3FaceStitch")!;
    assert.deepEqual(graph.keep_source_mouth.inputs.generated, [stitch[0], 0]);
    assert.deepEqual(graph.keep_source_mouth.inputs.source, stitch[1].inputs.base_images);
    assert.ok(Object.entries(graph).some(([id,n]) => id !== "keep_source_mouth" && Object.values(n.inputs).some(v => Array.isArray(v) && v[0] === "keep_source_mouth")));
    acyclic(graph);
  }
});
