import test from "node:test";
import assert from "node:assert/strict";
import {releaseIdleGpuPeer} from "../lib/gpu-coordination.ts";

test("idle peer cache is released, without interrupting or submitting a prompt", async () => {
  const calls: {path: string; init?: RequestInit}[] = [];
  await releaseIdleGpuPeer("http://127.0.0.1:8288", (async (url, init) => {
    calls.push({path: new URL(String(url)).pathname, init});
    const path = new URL(String(url)).pathname;
    return path === "/queue" ? Response.json({queue_running: [], queue_pending: []})
      : path === "/system_stats" ? Response.json({devices: [{torch_vram_total: 64 * 1024 ** 2}]}) : new Response("");
  }) as typeof fetch);
  assert.deepEqual(calls.map(c => c.path), ["/queue", "/free", "/system_stats"]);
  assert.deepEqual(JSON.parse(String(calls[1].init?.body)), {unload_models: true, free_memory: true});
});

test("active or queued peer renders are preserved and block a competing submission", async () => {
  for (const queue of [{queue_running: [[0,"id"]], queue_pending: []}, {queue_running: [], queue_pending: [[0,"id"]]}]) {
    let calls = 0;
    await assert.rejects(releaseIdleGpuPeer("http://127.0.0.1:8288", (async () => {
      calls++; return Response.json(queue);
    }) as typeof fetch), /Another ComfyUI render/);
    assert.equal(calls, 1);
  }
});

test("stopped peer and absent peer configuration allow submission without any GPU work", async () => {
  await releaseIdleGpuPeer("http://127.0.0.1:8288", (async () => {
    throw new TypeError("fetch failed", {cause: {code: "ECONNREFUSED"}});
  }) as typeof fetch);
  await releaseIdleGpuPeer("", (async () => {throw new Error("Should not contact a peer");}) as typeof fetch);
});

test("peer URL never permits external network requests", async () => {
  await assert.rejects(releaseIdleGpuPeer("https://example.com"), /must be a local/);
});

test("submission waits for confirmed GPU cleanup rather than trusting the free flag alone", async () => {
  let polls = 0;
  await releaseIdleGpuPeer("http://127.0.0.1:8288", (async url => {
    const path = new URL(String(url)).pathname;
    if (path === "/queue") return Response.json({queue_running: [], queue_pending: []});
    if (path === "/free") return new Response("");
    polls++;
    return Response.json({devices: [{torch_vram_total: polls < 3 ? 4 * 1024 ** 3 : 64 * 1024 ** 2}]});
  }) as typeof fetch);
  assert.equal(polls, 3);
});
