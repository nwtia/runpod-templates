import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";
import { applyModel, DEFAULT_MODEL } from "../lib/model.ts";
import { isLink, type ApiGraph } from "../lib/simple.ts";

const load = (name: string): ApiGraph => JSON.parse(readFileSync(new URL(`../workflows/${name}.api.json`, import.meta.url), "utf8"));
const workflows = ["simple", "advanced", "advanced_maxq", "object", "montage", "face"];

test("the fast profile reaches every H3 sampler without dropping style LoRAs or graph links", () => {
  for (const name of workflows) {
    const graph = load(name);
    applyModel(graph, { ...DEFAULT_MODEL, steps: 4, sampler: "lcm", loras: [...DEFAULT_MODEL.loras, { name: "style.safetensors", strength: 0.7 }] });
    const nodes = Object.values(graph);
    assert.ok(nodes.some((node) => node.class_type === "KSamplerSelect"), name);
    assert.ok(nodes.filter((node) => node.class_type === "KSamplerSelect").every((node) => node.inputs.sampler_name === "lcm"), name);
    assert.ok(nodes.filter((node) => node.class_type === "ModelAttentionBackend").every((node) => node.inputs.attention === "pytorch attention"), name);
    assert.deepEqual(nodes.filter((node) => node.class_type === "LoraLoaderModelOnly").map((node) => node.inputs.lora_name), [DEFAULT_MODEL.loras[0].name, "style.safetensors"], name);
    for (const node of nodes) for (const value of Object.values(node.inputs)) if (isLink(value)) assert.ok(graph[value[0]], name);
    const plan = nodes.find((node) => /^H3(OneClick|Advanced|Object|Montage)SwapPlan$/.test(node.class_type) || node.class_type === "H3FaceChunks");
    if (plan) assert.equal(plan.inputs.steps ?? nodes.find((node) => node.class_type === "BasicScheduler")?.inputs.steps, 4, name);
  }
});

test("original sampling and Kitchen attention remain selectable, with separate saved clips", () => {
  const identity = (settings: Parameters<typeof applyModel>[1]) => {
    const graph = load("simple");
    applyModel(graph, settings);
    return { graph, name: graph.model_run_name?.inputs.string_b };
  };
  const original = identity(DEFAULT_MODEL);
  const fast = identity({ ...DEFAULT_MODEL, steps: 4, sampler: "lcm" });
  const kitchen = identity({ ...DEFAULT_MODEL, attention: "comfy kitchen attention" });
  const fourEuler = identity({ ...DEFAULT_MODEL, steps: 4 });
  assert.ok(Object.values(original.graph).filter((node) => node.class_type === "KSamplerSelect").every((node) => node.inputs.sampler_name === "euler"));
  assert.ok(Object.values(kitchen.graph).filter((node) => node.class_type === "ModelAttentionBackend").every((node) => node.inputs.attention === "comfy kitchen attention"));
  assert.equal(new Set([original.name, fast.name, kitchen.name, fourEuler.name]).size, 4);
  for (const settings of [{ ...DEFAULT_MODEL, sampler: "invalid" }, { ...DEFAULT_MODEL, attention: "invalid" }]) {
    const graph = load("simple");
    const before = structuredClone(graph);
    assert.throws(() => applyModel(graph, settings as Parameters<typeof applyModel>[1]));
    assert.deepEqual(graph, before);
  }
});
