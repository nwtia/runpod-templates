import assert from "node:assert/strict";
import { createServer, type Server } from "node:net";
import test from "node:test";
import { existsSync } from "node:fs";
import { apiAccess, authorize, HttpError, IMAGE_SIGNATURE, loopbackOnly, PASSWORD_REQUIRED, PASSWORD_TOO_SHORT, readFormData, StoredFile, uploadName, validateJobId, VIDEO_SIGNATURE } from "../lib/http.ts";
import { getJob } from "../lib/comfy.ts";
import { register } from "../instrumentation.ts";

test("URL-shaped job IDs are rejected before the SDK can fetch", async (t) => {
  let requests = 0;
  t.mock.method(globalThis, "fetch", async () => { requests++; throw new Error("Unexpected network request"); });
  for (const id of ["http://127.0.0.1:8188/queue", "https://example.com", "/api/v2/assets", "..", "a/b", "a\\b", "a%2fb", "http-other", ""]) {
    await assert.rejects(async () => getJob(id), (error: unknown) => error instanceof HttpError && error.status === 400);
  }
  assert.equal(requests, 0);
  for (const id of ["d544f17b-2c81-40c4-9cd1-9624954038e6", "job_abc-123"]) assert.doesNotThrow(() => validateJobId(id));
});

test("local API access stays password-free; foreign hosts and browser origins are rejected", (t) => {
  const previous = process.env.OPENJUTSU_PASSWORD;
  delete process.env.OPENJUTSU_PASSWORD;
  t.after(() => { if (previous === undefined) delete process.env.OPENJUTSU_PASSWORD; else process.env.OPENJUTSU_PASSWORD = previous; });
  for (const host of ["127.0.0.1:3000", "localhost:3000", "[::1]:3000"]) {
    const url = `http://${host}`;
    assert.equal(apiAccess(new Request(`${url}/api/jobs`, { headers: { Host: host, Origin: url, "Sec-Fetch-Site": "same-origin" } })), null);
  }
  assert.equal(apiAccess(new Request("http://localhost:3000/api/jobs", { headers: { Host: "127.0.0.1:3000", Origin: "http://127.0.0.1:3000" } })), null, "Next may use its internal hostname in request.url");
  assert.equal(apiAccess(new Request("http://localhost:3000/api/jobs", { headers: { Host: "localhost:3000", Origin: "https://localhost:3000", "X-Forwarded-Proto": "https" } })), null, "reverse proxies preserve the public scheme");
  const foreignHeaders: HeadersInit[] = [
    { Origin: "https://example.com" }, { Origin: "null" }, { "Sec-Fetch-Site": "cross-site" },
    { "Sec-Fetch-Site": "same-site" }, { Host: "example.com" }, { "X-Forwarded-Host": "example.com" },
  ];
  for (const headers of foreignHeaders) assert.equal(apiAccess(new Request("http://127.0.0.1:3000/api/jobs", { headers }))?.status, 403);
  assert.equal(authorize(new Request("https://example.com"))?.status, 403);
  assert.equal(authorize(new Request("http://localhost:3000", { headers: { "Sec-Fetch-Site": "cross-site" } })), null, "ordinary page navigation is allowed");
});

test("password-free serving starts only on loopback; a network bind needs a password", async (t) => {
  const previous = { password: process.env.OPENJUTSU_PASSWORD, runtime: process.env.NEXT_RUNTIME };
  delete process.env.OPENJUTSU_PASSWORD;
  process.env.NEXT_RUNTIME = "nodejs";
  const servers: Server[] = [];
  t.after(() => {
    for (const [key, value] of [["OPENJUTSU_PASSWORD", previous.password], ["NEXT_RUNTIME", previous.runtime]] as const) {
      if (value === undefined) delete process.env[key]; else process.env[key] = value;
    }
    for (const server of servers) server.close();
  });
  const listen = (host: string) => new Promise<void>((resolve) => { const server = createServer(); servers.push(server); server.listen(0, host, resolve); });
  const errors: unknown[] = [];
  t.mock.method(console, "error", (message: unknown) => { errors.push(message); });
  t.mock.method(process, "exit", (code?: number) => { throw new Error(`exit ${code}`); });

  for (const address of ["127.0.0.1", "127.8.0.1", "::1", "::ffff:127.0.0.1"]) assert.equal(loopbackOnly([{ address, family: "", port: 3000 }]), true, address);
  assert.equal(loopbackOnly(["/tmp/openjutsu.sock"]), true, "pipes are local");
  for (const address of ["0.0.0.0", "::", "192.168.1.20", "::ffff:10.0.0.2"]) assert.equal(loopbackOnly([{ address, family: "", port: 3000 }]), false, address);
  assert.equal(loopbackOnly([]), false, "no listening socket proves nothing");
  assert.equal(loopbackOnly([null]), false);

  await assert.rejects(register(), /exit 1/, "nothing listening yet is not proof of loopback");
  await listen("127.0.0.1");
  await register();
  await listen("0.0.0.0");
  await assert.rejects(register(), /exit 1/);
  assert.deepEqual(errors, [PASSWORD_REQUIRED, PASSWORD_REQUIRED]);
  process.env.OPENJUTSU_PASSWORD = "review-test-password";
  await register();
  assert.equal(errors.length, 2);
  process.env.OPENJUTSU_PASSWORD = "elevenchars";
  await assert.rejects(register(), /exit 1/, "a short password is refused even on loopback");
  assert.equal(errors.at(-1), PASSWORD_TOO_SHORT);
  process.env.OPENJUTSU_PASSWORD = "twelve-chars";
  await register();
  assert.equal(errors.length, 3);
});

test("a configured password protects local and hosted access, including media and event requests", (t) => {
  const previous = process.env.OPENJUTSU_PASSWORD;
  process.env.OPENJUTSU_PASSWORD = "review-test-password";
  t.after(() => { if (previous === undefined) delete process.env.OPENJUTSU_PASSWORD; else process.env.OPENJUTSU_PASSWORD = previous; });
  const authorization = `Basic ${Buffer.from("openjutsu:review-test-password").toString("base64")}`;
  for (const host of ["http://127.0.0.1:3000", "https://openjutsu.example"]) {
    for (const path of ["/", "/api/models", "/api/jobs/job_123/events", "/api/jobs/job_123/outputs/asset_1"]) {
      const url = `${host}${path}`;
      assert.equal(authorize(new Request(url))?.status, 401);
      assert.equal(apiAccess(new Request(url, { headers: { Authorization: authorization, "Sec-Fetch-Site": "same-origin" } })), null);
      assert.equal(authorize(new Request(url, { headers: { Authorization: "Basic !!!" } }))?.status, 401);
    }
  }
  assert.equal(apiAccess(new Request("http://localhost:3000/api/jobs", { headers: { Authorization: authorization, Host: "openjutsu.example", Origin: "https://openjutsu.example", "X-Forwarded-Proto": "https" } })), null, "public origin must not inherit the internal port");
  assert.equal(apiAccess(new Request("http://localhost:3000/api/jobs", { headers: { Authorization: authorization, Host: "openjutsu.example", Origin: "https://openjutsu.example:3000", "X-Forwarded-Proto": "https" } }))?.status, 403);
  assert.match(authorize(new Request("http://localhost:3000"))!.headers.get("WWW-Authenticate")!, /^Basic /);
  assert.equal(apiAccess(new Request("https://openjutsu.example/api/jobs", { headers: { Authorization: authorization, Origin: "https://attacker.example" } }))?.status, 403);
});

test("failed sign-ins back off per client and across forged clients; the right password from a fresh client is never slowed", (t) => {
  const previous = process.env.OPENJUTSU_PASSWORD;
  process.env.OPENJUTSU_PASSWORD = "review-test-password";
  t.after(() => { if (previous === undefined) delete process.env.OPENJUTSU_PASSWORD; else process.env.OPENJUTSU_PASSWORD = previous; });
  // Start hours after the failures in earlier tests so they are forgotten.
  let now = performance.now() + 2 * 60 * 60_000;
  t.mock.method(performance, "now", () => now);
  const signIn = (password: string | null, client = "203.0.113.7") => {
    const headers: Record<string, string> = { "X-Forwarded-For": `198.51.100.1, ${client}` };
    if (password !== null) headers.Authorization = `Basic ${Buffer.from(`openjutsu:${password}`).toString("base64")}`;
    return authorize(new Request("https://openjutsu.example/api/models", { headers }));
  };
  const status = (password: string | null, client?: string) => signIn(password, client)?.status ?? 200;

  for (let i = 0; i < 6; i++) assert.equal(status("wrong"), 401, `failure ${i + 1} is answered`);
  const refused = signIn("wrong")!;
  assert.equal(refused.status, 429);
  assert.equal(refused.headers.get("Retry-After"), "1");
  assert.equal(status("review-test-password"), 429, "a client in backoff cannot test even the right password");
  assert.equal(status(null), 401, "asking for the sign-in prompt is never refused");
  assert.equal(status("review-test-password", "203.0.113.8"), 200, "other clients sign in at once, keyed by the entry nearest the proxy");
  now += 1000;
  assert.equal(status("wrong"), 401);
  now += 1000;
  assert.equal(status("wrong"), 429, "the delay doubles");
  now += 1000;
  assert.equal(status("review-test-password"), 200);
  assert.equal(status("wrong"), 401, "success clears the client's failures");
  for (let i = 0; i < 6; i++) status("wrong");
  now += 60 * 60_000 + 1;
  assert.equal(status("wrong"), 401, "failures are forgotten after an hour");

  now += 60 * 60_000 + 1;
  for (let i = 0; i < 21; i++) assert.equal(status("wrong", `forged-${i}`), 401);
  assert.equal(status("wrong", "forged-new"), 429, "forged client addresses share one allowance");
  assert.equal(status("review-test-password", "203.0.113.9"), 429);
  now += 1000;
  assert.equal(status("review-test-password", "203.0.113.9"), 200);
});

test("bounded multipart parsing preserves video bytes, duplicate pictures and roles", async () => {
  const form = new FormData();
  form.set("video", new File([new Uint8Array([0, 1, 255])], "clip.mp4", { type: "video/mp4" }));
  for (const name of ["one", "two"]) {
    form.append("picture", new File([name], `${name}.png`, { type: "image/png" }));
    form.append("role", name);
  }
  const { form: parsed, dispose } = await readFormData(new Request("http://localhost/api/jobs", { method: "POST", body: form }), {}, 4096);
  assert.deepEqual(parsed.getAll("role"), ["one", "two"]);
  assert.deepEqual(parsed.getAll("picture").map((file) => (file as File).name), ["one.png", "two.png"]);
  assert.deepEqual(new Uint8Array(await (parsed.get("video") as File).arrayBuffer()), new Uint8Array([0, 1, 255]));
  await dispose();
});

test("declared oversize bodies are rejected without reading them", async () => {
  let read = false;
  const body = new ReadableStream({ pull() { read = true; } }, { highWaterMark: 0 });
  const init = { method: "POST", body, duplex: "half", headers: { "Content-Length": "2048" } };
  await assert.rejects(readFormData(new Request("http://localhost/api/jobs", init), {}, 1024), (e: unknown) => e instanceof HttpError && e.status === 413);
  assert.equal(read, false);
});

test("chunked uploads cannot bypass the limit with a missing or false Content-Length", async () => {
  for (const length of [null, "1"]) {
    let pulls = 0;
    let canceled = false;
    const body = new ReadableStream<Uint8Array>({
      pull(controller) { pulls++; controller.enqueue(new Uint8Array(512)); },
      cancel() { canceled = true; },
    }, { highWaterMark: 0 });
    const headers = new Headers({ "Content-Type": "multipart/form-data; boundary=test" });
    if (length !== null) headers.set("Content-Length", length);
    const init = { method: "POST", body, duplex: "half", headers };
    await assert.rejects(readFormData(new Request("http://localhost/api/jobs", init), {}, 1024), (e: unknown) => e instanceof HttpError && e.status === 413);
    await new Promise<void>((resolve) => setImmediate(resolve));
    assert.equal(canceled, true);
    assert.equal(pulls, 3);
  }
});

async function multipart(form: FormData) {
  const response = new Response(form);
  return { body: new Uint8Array(await response.arrayBuffer()), type: response.headers.get("Content-Type")! };
}

function chunked(body: Uint8Array, type: string, size: number) {
  let offset = 0;
  const stream = new ReadableStream<Uint8Array>({
    pull(controller) {
      if (offset >= body.length) return controller.close();
      controller.enqueue(body.slice(offset, offset += size));
    },
  });
  return new Request("http://localhost/api/jobs", { method: "POST", body: stream, duplex: "half", headers: { "Content-Type": type } } as RequestInit);
}

test("multipart parts split at any byte come back whole, with files on disk until disposed", async () => {
  const video = new Uint8Array(3000).map((_, i) => i % 251);
  video.set([13, 10, 45, 45], 1000);
  const form = new FormData();
  form.set("mode", "simple");
  form.set("video", new File([video], "my clip?.mp4", { type: "video/mp4" }));
  form.set("role", "the dancer — white polo");
  form.append("picture", new File(["a"], "same.png", { type: "image/png" }));
  form.append("picture", new File(["b"], "same.png", { type: "image/png" }));
  const { body, type } = await multipart(form);
  for (const size of [1, 2, 7, 64, 1000, body.length]) {
    const { form: parsed, dispose } = await readFormData(chunked(body, type, size));
    assert.equal(parsed.get("mode"), "simple");
    assert.equal(parsed.get("role"), "the dancer — white polo");
    const file = parsed.get("video") as StoredFile;
    assert.ok(file instanceof StoredFile);
    assert.equal(file.name, "my clip?.mp4");
    assert.equal(file.type, "video/mp4");
    assert.match(file.path, /my clip_\.mp4$/);
    assert.deepEqual(new Uint8Array(await file.arrayBuffer()), video);
    const pictures = parsed.getAll("picture") as StoredFile[];
    assert.deepEqual(await Promise.all(pictures.map((picture) => picture.text())), ["a", "b"]);
    assert.notEqual(pictures[0].path, pictures[1].path);
    await dispose();
    assert.equal(existsSync(file.path), false);
  }
});

test("truncated or malformed multipart bodies are refused and leave no temp files", async () => {
  const form = new FormData();
  form.set("video", new File(["0123456789abcdef"], "clip.mp4"));
  const { body, type } = await multipart(form);
  const refuse = (bytes: Uint8Array, contentType = type) => assert.rejects(readFormData(chunked(bytes, contentType, 5)), (e: unknown) => e instanceof HttpError && e.status === 400);
  await refuse(body.slice(0, body.length - 10));
  await refuse(body.slice(0, 60));
  await refuse(body, "application/x-www-form-urlencoded");
  await refuse(new TextEncoder().encode(`--${type.split("boundary=")[1]}\r\n${"x".repeat(20000)}`));
});

test("file checks read the first bytes as they arrive and stop the upload there", async () => {
  const checks = { video: { signature: VIDEO_SIGNATURE, error: "Not a video." }, picture: { signature: IMAGE_SIGNATURE, error: "Not a picture." } };
  const form = new FormData();
  form.set("video", new File(["#!/bin/sh", "x".repeat(100_000)], "clip.mp4", { type: "video/mp4" }));
  const { body, type } = await multipart(form);
  let read = 0;
  const stream = new ReadableStream<Uint8Array>({
    pull(controller) {
      controller.enqueue(body.slice(read, read += 1000));
      if (read >= body.length) controller.close();
    },
  }, { highWaterMark: 0 });
  const request = new Request("http://localhost/api/jobs", { method: "POST", body: stream, duplex: "half", headers: { "Content-Type": type } } as RequestInit);
  await assert.rejects(readFormData(request, checks), (e: unknown) => e instanceof HttpError && e.status === 400 && e.message === "Not a video.");
  assert.ok(read <= 1000);

  const short = new FormData();
  short.set("picture", new File([new Uint8Array([0xff, 0xd8, 0xff])], "tiny.jpg", { type: "image/jpeg" }));
  short.set("video", new File([], "none.mp4"));
  const { form: parsed, dispose } = await readFormData(new Request("http://localhost/api/jobs", { method: "POST", body: short }), checks);
  assert.equal((parsed.get("picture") as File).size, 3);
  await dispose();
});

test("signatures accept the containers ComfyUI reads and nothing else", () => {
  const bytes = (...parts: (string | number[])[]) => Buffer.concat(parts.map((part) => Buffer.from(part as string, typeof part === "string" ? "latin1" : undefined))).toString("latin1");
  for (const head of [bytes([0, 0, 0, 0x20], "ftypisom"), bytes([0, 0, 0, 0x14], "ftypqt  "), bytes([0x1a, 0x45, 0xdf, 0xa3, 0x9f]), bytes("RIFF", [1, 2, 3, 4], "AVI LIST")]) assert.ok(VIDEO_SIGNATURE.test(head), head);
  for (const head of [bytes("RIFF", [1, 2, 3, 4], "WAVE"), bytes("ftypisom...."), bytes("<html>"), bytes([0x89], "PNG\r\n\x1a\n")]) assert.ok(!VIDEO_SIGNATURE.test(head), head);
  for (const head of [bytes([0x89], "PNG\r\n\x1a\n"), bytes([0xff, 0xd8, 0xff, 0xe0]), bytes("RIFF", [1, 2, 3, 4], "WEBPVP8 ")]) assert.ok(IMAGE_SIGNATURE.test(head), head);
  for (const head of [bytes("GIF89a"), bytes("<svg>"), bytes("RIFF", [1, 2, 3, 4], "AVI "), bytes([0xff, 0xd8])]) assert.ok(!IMAGE_SIGNATURE.test(head), head);
});

test("upload names are safe as file names everywhere", () => {
  assert.equal(uploadName("../../etc/passwd"), ".._.._etc_passwd");
  assert.equal(uploadName("C:\\Users\\me\\clip.mp4"), "C_Users_me_clip.mp4");
  assert.equal(uploadName("CON.mp4"), "_CON.mp4");
  assert.equal(uploadName("lpt1"), "_lpt1");
  assert.equal(uploadName("console.mp4"), "console.mp4");
  assert.equal(uploadName("..."), "upload");
  assert.equal(uploadName("clip.mp4. "), "clip.mp4");
  assert.equal(uploadName(""), "upload");
});

test("explicit password-free Tailscale hosts retain origin and hostname checks", (t) => {
  const keys = ["OPENJUTSU_PASSWORD", "OPENJUTSU_PASSWORDLESS_HOSTS"] as const;
  const previous = keys.map((key) => process.env[key]);
  t.after(() => keys.forEach((key, i) => {
    if (previous[i] === undefined) delete process.env[key]; else process.env[key] = previous[i];
  }));
  delete process.env.OPENJUTSU_PASSWORD;
  process.env.OPENJUTSU_PASSWORDLESS_HOSTS = "100.104.37.49:3000, desktop-095hd6h.tail8f6324.ts.net:3000";
  const origin = "http://100.104.37.49:3000";
  const request = (extra: Record<string, string> = {}) => new Request("http://localhost:3000/api/models", {
    headers: { Host: "100.104.37.49:3000", Origin: origin, ...extra },
  });
  assert.equal(apiAccess(request()), null);
  assert.equal(authorize(new Request(`${origin}/`)), null);
  assert.equal(authorize(new Request("http://desktop-095hd6h.tail8f6324.ts.net:3000/")), null);
  assert.equal(apiAccess(request({ Origin: "https://attacker.example" }))?.status, 403);
  assert.equal(apiAccess(request({ "X-Forwarded-Host": "attacker.example" }))?.status, 403);
  assert.equal(authorize(new Request("http://100.104.37.49:3001/"))?.status, 403);
  assert.equal(authorize(new Request("http://100.104.37.49.attacker.example:3000/"))?.status, 403);
  process.env.OPENJUTSU_PASSWORD = "review-test-password";
  assert.equal(apiAccess(request())?.status, 401, "a configured password still takes precedence");
});
