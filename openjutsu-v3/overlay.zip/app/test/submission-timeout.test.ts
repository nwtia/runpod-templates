import assert from "node:assert/strict";
import test from "node:test";
import {register} from "node:module";
import {fakeProxy} from "./proxy.ts";

register("data:text/javascript,export const resolve = (specifier, context, next) => next(specifier === 'next/server' ? 'next/server.js' : specifier, context);");

test("an accepted submission whose response times out is not retried and keeps its input assets", async () => {
  const proxy = await fakeProxy();
  const originalFetch = globalThis.fetch;
  let submissions = 0;
  process.env.COMFY_BASE_URL = proxy.url;
  process.env.COMFYUI_URL = proxy.url;
  delete process.env.OPENJUTSU_GPU_PEER;
  delete process.env.OPENJUTSU_PASSWORD;
  globalThis.fetch = (async (url, init) => {
    const response = await originalFetch(url, init);
    if (String(url).endsWith("/api/v2/jobs") && init?.method === "POST") {
      submissions++;
      await response.arrayBuffer();
      throw new DOMException("The operation was aborted due to timeout", "TimeoutError");
    }
    return response;
  }) as typeof fetch;
  try {
    const {POST} = await import("../app/api/jobs/route.ts");
    const form = new FormData();
    const fields = {mode:"simple",role:"",resolution:"480p",motion:"512",seed:"1",clip_seconds:"6",steps:"8",model:"base.safetensors"};
    for (const [key,value] of Object.entries(fields)) form.set(key,value);
    form.set("video",new File([new Uint8Array([0,0,0,0x18]),"ftypisom","neutral timeout fixture"],"fixture.mp4",{type:"video/mp4"}));
    form.set("picture",new File([new Uint8Array([0x89,0x50,0x4e,0x47,0x0d,0x0a,0x1a,0x0a]),"neutral fixture"],"fixture.png",{type:"image/png"}));
    const response = await POST(new Request("http://127.0.0.1:3000/api/jobs",{method:"POST",body:form}));
    assert.equal(response.status,502);
    assert.match((await response.json()).error,/may already exist/);
    assert.equal(submissions,1);
    assert.equal(proxy.jobs.size,1);
    const job = [...proxy.jobs.values()][0];
    assert.equal(job.inputs.length,2);
    for (const id of job.inputs) assert.ok(proxy.assets.has(id),"Accepted job input was deleted");
  } finally {
    globalThis.fetch = originalFetch;
    const held = (globalThis as {[key:symbol]: Map<string,unknown>})[Symbol.for("openjutsu.inputs")];
    held?.clear();
    await proxy.close();
  }
});
