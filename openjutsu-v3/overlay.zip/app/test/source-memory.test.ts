import assert from "node:assert/strict";
import test from "node:test";
import { initialSourceLength, sourceBytes, sourceMemoryError } from "../lib/source-memory.ts";
test("long 720p sources default to a short selection rather than a hundreds-of-GiB allocation",()=>{
  const bytes=sourceBytes(1280,720,1087.808);
  assert.ok(bytes / 1024 ** 3 > 268 && bytes / 1024 ** 3 < 270);
  assert.equal(initialSourceLength(1280,720,1087.808),6);
  assert.match(sourceMemoryError(1280,720,1087.808)!,/Choose a shorter part/);
});
test("an 11-second 720p selection is allowed without resizing or changing frames",()=>{
  assert.equal(sourceBytes(1280,720,11),264*1280*720*3*4);
  assert.equal(sourceMemoryError(1280,720,11),null);
  assert.equal(initialSourceLength(1280,720,11),11);
});
test("unknown metadata does not produce an invalid allocation estimate",()=>{
  assert.equal(sourceBytes(0,0,0),0);
  assert.equal(sourceMemoryError(1280,720,NaN),null);
});

test("4K sources start with a part that fits the budget",()=>{
  const length=initialSourceLength(3840,2160,90);
  assert.ok(length < 6 && length >= 2);
  assert.equal(sourceMemoryError(3840,2160,length),null);
});
