import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";
import { applyModel, DEFAULT_MODEL, SMALL_ENCODER } from "../lib/model.ts";
import { isLink, type ApiGraph } from "../lib/simple.ts";

test("2.0 caches only the visual describer's text nodes and preserves all inference parameters and LoRAs", () => {
  for (const name of ["simple","advanced","advanced_maxq","object","montage","face"]) {
    const graph: ApiGraph = JSON.parse(readFileSync(new URL(`../workflows/${name}.api.json`, import.meta.url),"utf8"));
    const original=structuredClone(graph);
    applyModel(graph,{...DEFAULT_MODEL,textEncoder:SMALL_ENCODER});
    for (const [id,node] of Object.entries(original)) {
      if (node.class_type !== "TextGenerate") continue;
      const link=node.inputs.clip;
      const captioner=isLink(link) && original[link[0]]._meta?.title === "Describer: Qwen3-VL 8B";
      assert.equal(graph[id].class_type,captioner?"OpenJutsuTextGenerateCached":"TextGenerate",name+"/"+id);
      assert.deepEqual(graph[id].inputs,node.inputs,name+"/"+id);
    }
    const loader=Object.values(graph).find(n=>n._meta?.title === "Describer: Qwen3-VL 8B")!;
    assert.equal(loader.class_type,"OpenJutsuDescriberLoader");
    assert.deepEqual(Object.values(graph).filter(n=>n.class_type === "LoraLoaderModelOnly").map(n=>[n.inputs.lora_name,n.inputs.strength_model]),DEFAULT_MODEL.loras.map(l=>[l.name,l.strength]));
  }
});
