import assert from "node:assert/strict";
import test from "node:test";
import { postSetup, postUpload, prepareUpload } from "../lib/browser-upload.ts";

test("small disk-backed files become stable blobs with names, MIME types and duplicate fields preserved", async () => {
  const form = new FormData();
  form.append("video", new File(["selected video"], "clip.mp4", { type: "video/mp4" }));
  form.append("lora", "one"); form.append("lora", "two");
  const selected = form.get("video") as File;
  const stable = await prepareUpload(form);
  Object.defineProperty(selected, "arrayBuffer", { value: () => Promise.reject(new Error("file changed")) });
  const upload = stable.get("video") as File;
  assert.notEqual(upload, selected);
  assert.equal(upload.name, "clip.mp4");
  assert.equal(upload.type, "video/mp4");
  assert.equal(await upload.text(), "selected video");
  assert.deepEqual(stable.getAll("lora"), ["one", "two"]);
});

test("large videos keep streaming and leave snapshot budget available for a photo", async () => {
  const form = new FormData();
  form.append("video", new File(["large video"], "clip.mp4"));
  form.append("picture", new File(["png"], "photo.png", { type: "image/png" }));
  const video = form.get("video") as File;
  Object.defineProperty(video, "arrayBuffer", { value: () => { throw new Error("must not buffer the whole video"); } });
  const stable = await prepareUpload(form, 4);
  assert.equal(stable.get("video"), video);
  assert.notEqual(stable.get("picture"), form.get("picture"));
  assert.equal(await (stable.get("picture") as File).text(), "png");
});

test("an unreadable selection is reported before any upload request", async (t) => {
  const form = new FormData();
  form.append("video", new File(["video"], "clip.mp4"));
  Object.defineProperty(form.get("video"), "arrayBuffer", { value: () => Promise.reject(new Error("not readable")) });
  let requests = 0;
  t.mock.method(globalThis, "fetch", async () => { requests++; return new Response(); });
  await assert.rejects(postUpload(form), /selected video.*Select it again/);
  assert.equal(requests, 0);
});

test("a transient setup failure retries the same stateless request with same-origin credentials", async (t) => {
  const requests: RequestInit[] = [];
  t.mock.method(globalThis, "fetch", async (_url: unknown, init: RequestInit) => {
    requests.push(init);
    if (requests.length === 1) throw new TypeError("Failed to fetch");
    return Response.json({ ok: true });
  });
  assert.equal((await postSetup({ kind: "simple" })).status, 200);
  assert.equal(requests.length, 2);
  assert.equal(requests[0].credentials, "same-origin");
  assert.equal(requests[0].body, requests[1].body);
});

test("HTTP authentication errors are returned without retrying", async (t) => {
  let requests = 0;
  t.mock.method(globalThis, "fetch", async () => { requests++; return Response.json({ error: "Sign in" }, { status: 401 }); });
  assert.equal((await postSetup({ kind: "simple" })).status, 401);
  assert.equal(requests, 1);
});

test("a lost job response is never automatically submitted again", async (t) => {
  let requests = 0;
  t.mock.method(globalThis, "fetch", async () => { requests++; throw new TypeError("Failed to fetch"); });
  await assert.rejects(postUpload(new FormData()), /job status could not be confirmed.*Recent jobs/);
  assert.equal(requests, 1);
});
