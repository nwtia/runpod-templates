import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";
import { applyModel, DEFAULT_MODEL, SMALL_ENCODER } from "../lib/model.ts";
import { applyV3Caching } from "../lib/v3.ts";
import type { ApiGraph } from "../lib/simple.ts";

const native: Record<string, string> = {
  OpenJutsu3CheckpointLoader: "CheckpointLoaderSimple", OpenJutsu3CLIPLoader: "CLIPLoader",
  OpenJutsu3VAELoader: "VAELoader", OpenJutsu3ClipProjApply: "ClipProjApply",
  OpenJutsu3VideoTrackCached: "SAM3_VideoTrack", OpenJutsu3ReferenceCached: "MiniMaxH3ReferenceToVideo",
  OpenJutsu3EditLatentCached: "MiniMaxH3FantasticVideoEditLatent",
};

test("V3 preserves the complete V2 graph, parameters and LoRA chain in all six generation modes", () => {
  for (const mode of ["simple", "advanced", "advanced_maxq", "object", "montage", "face"]) {
    for (const textEncoder of [SMALL_ENCODER, DEFAULT_MODEL.textEncoder]) {
      const graph: ApiGraph = JSON.parse(readFileSync(new URL(`../workflows/${mode}.api.json`, import.meta.url), "utf8"));
      const v2 = structuredClone(graph);
      const settings = {...DEFAULT_MODEL, textEncoder, loras: [...DEFAULT_MODEL.loras, {name: "custom.safetensors", strength: 0.7}]};
      applyModel(v2, {...settings, cacheMode: "v2"});
      applyModel(graph, {...settings, cacheMode: "v3"});
      assert.ok(Object.values(graph).some(n => n.class_type === "OpenJutsu3ReferenceCached"), mode);
      for (const node of Object.values(graph)) node.class_type = native[node.class_type] ?? node.class_type;
      assert.deepEqual(graph, v2, mode + "/" + textEncoder);
    }
  }
});

test("V3 graph mapping is idempotent and leaves unknown model paths executable", () => {
  const graph: ApiGraph = {
    a: {class_type: "CustomLoader", inputs: {}},
    b: {class_type: "SAM3_VideoTrack", inputs: {model: ["a", 0], detect_interval: 1, max_objects: 0}},
  };
  applyV3Caching(graph);
  const once = structuredClone(graph);
  applyV3Caching(graph);
  assert.deepEqual(graph, once);
  assert.equal(graph.a.class_type, "CustomLoader");
});
