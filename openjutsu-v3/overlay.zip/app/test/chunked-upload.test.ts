import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import test from "node:test";
import { needsChunkedUpload, postChunkedUpload } from "../lib/chunked-upload.ts";

test("large multipart is sent unchanged in bounded parts and a lost part response is retried safely", async (t) => {
  const original = new Uint8Array(33 * 1024 * 1024); original.fill(153);
  const form = new FormData(); form.append("video", new File([original], "public-test.mp4", {type:"video/mp4"}));
  form.append("lora", "first"); form.append("lora", "second");
  const parts = new Map<string, Uint8Array>(); let contentType="", commits=0, lost=false;
  t.mock.method(globalThis, "fetch", async (url: string, init: RequestInit) => {
    assert.equal(init.credentials, "same-origin");
    if (url.endsWith("/uploads")) {
      contentType=JSON.parse(String(init.body)).contentType;
      return Response.json({uploadId:JSON.parse(String(init.body)).uploadId,chunkBytes:8*1024*1024},{status:201});
    }
    if (init.method==="PUT") {
      const bytes = init.body as Uint8Array;
      assert.ok(bytes.length<=8*1024*1024);
      assert.equal((init.headers as Record<string,string>)["Upload-Sha256"], createHash("sha256").update(bytes).digest("hex"));
      parts.set(url,bytes);
      if (!lost) {lost=true; throw new TypeError("Lost response after storing part");}
      return Response.json({ok:true});
    }
    commits++; return Response.json({id:"diagnostic-only"},{status:202});
  });
  assert.ok(needsChunkedUpload(form));
  assert.equal((await (await postChunkedUpload(form)).json()).id,"diagnostic-only");
  assert.equal(commits,1);
  const restored=await new Response(Buffer.concat([...parts.values()]),{headers:{"Content-Type":contentType}}).formData();
  assert.deepEqual(restored.getAll("lora"),["first","second"]);
  const video=restored.get("video") as File;
  assert.equal(video.name,"public-test.mp4");
  assert.equal(createHash("sha256").update(new Uint8Array(await video.arrayBuffer())).digest("hex"),createHash("sha256").update(original).digest("hex"));
});

test("over-limit files fail before any upload request", async (t) => {
  const file=new File(["x"],"too-large.mp4"); Object.defineProperty(file,"size",{value:2*1024**3});
  const form=new FormData(); form.append("video",file); let calls=0;
  t.mock.method(globalThis,"fetch",async()=>{calls++;return new Response();});
  await assert.rejects(postChunkedUpload(form),/less than 2 GiB/); assert.equal(calls,0);
});
