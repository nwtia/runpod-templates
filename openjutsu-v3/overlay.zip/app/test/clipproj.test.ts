import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";
import { applyModel, DEFAULT_MODEL, SMALL_ENCODER, CLIPPROJ_PROJECTION, upgradeSmallEncoderProfile, DEFAULT_SMALL_DESCRIBER } from "../lib/model.ts";
import { isLink, type ApiGraph } from "../lib/simple.ts";

const load = (name: string): ApiGraph => JSON.parse(readFileSync(new URL(`../workflows/${name}.api.json`, import.meta.url), "utf8"));

test("4B projection reaches every H3 consumer while preserving the LoRA chain and render settings", () => {
  for (const name of ["simple", "advanced", "advanced_maxq", "object", "montage", "face"]) {
    const graph = load(name);
    const original = structuredClone(graph);
    const encoder = Object.keys(graph).find((id) => graph[id]._meta?.title === "H3 Text Encoder")!;
    const consumers = Object.entries(graph).flatMap(([id, node]) => Object.entries(node.inputs)
      .filter(([, v]) => isLink(v) && v[0] === encoder).map(([input]) => [id, input]));
    const settings = { ...DEFAULT_MODEL, steps: 6, describer: SMALL_ENCODER, textEncoder: SMALL_ENCODER,
      loras: [...DEFAULT_MODEL.loras, { name: "style.safetensors", strength: 0.7 }] };
    applyModel(graph, settings);
    const projection = `${encoder}_clipproj`;
    assert.equal(graph[encoder].inputs.type, "krea2");
    assert.deepEqual(graph[projection].inputs, { clip: [encoder, 0], projection: CLIPPROJ_PROJECTION });
    for (const [id, input] of consumers) assert.deepEqual(graph[id].inputs[input], [projection, 0], `${name}/${id}/${input}`);
    const baseline = structuredClone(original);
    applyModel(baseline, { ...settings, textEncoder: DEFAULT_MODEL.textEncoder });
    for (const [id, node] of Object.entries(graph)) {
      if (["LoraLoaderModelOnly", "KSamplerSelect", "UNETLoader", "BasicScheduler", "ModelAttentionBackend"].includes(node.class_type))
        assert.deepEqual(node, baseline[id], `${name}/${id}`);
      for (const value of Object.values(node.inputs)) if (isLink(value)) assert.ok(graph[value[0]], `${name}/${id}`);
    }
    const captioner = Object.values(graph).find((n) => n._meta?.title === "Describer: Qwen3-VL 8B")!;
    assert.equal(captioner.inputs.clip_name, SMALL_ENCODER);
    assert.equal(captioner.inputs.type, "stable_diffusion");
  }
});

test("the original 32B path stays available and has no projection", () => {
  const graph = load("simple");
  applyModel(graph, DEFAULT_MODEL);
  assert.ok(!Object.values(graph).some((n) => n.class_type === "ClipProjApply"));
  const encoder = Object.values(graph).find((n) => n._meta?.title === "H3 Text Encoder")!;
  assert.equal(encoder.inputs.type, "minimax");
});

test("the one-time encoder upgrade preserves LoRAs and render settings, and respects later legacy/custom choices", () => {
  const settings = { ...DEFAULT_MODEL, describer: "qwen3vl_8b_int8_convrot.safetensors", resolution: "480p", seed: 42,
    loras: [...DEFAULT_MODEL.loras, { name: "style.safetensors", strength: 0.6 }] };
  const upgraded = upgradeSmallEncoderProfile(settings, false);
  assert.deepEqual(upgraded, { ...settings, describer: DEFAULT_SMALL_DESCRIBER, textEncoder: SMALL_ENCODER });
  assert.equal(upgraded.loras, settings.loras);
  assert.equal(settings.textEncoder, DEFAULT_MODEL.textEncoder);
  assert.equal(upgradeSmallEncoderProfile(settings, true), settings);
  const custom = { ...settings, describer: "my_custom_vlm.safetensors" };
  assert.equal(upgradeSmallEncoderProfile(custom, false), custom);
});
