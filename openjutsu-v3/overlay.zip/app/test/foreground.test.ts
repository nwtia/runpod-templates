import test from "node:test";
import assert from "node:assert/strict";
import {readFileSync} from "node:fs";
import {parseProtectedObject, protectionSuffix} from "../lib/foreground.ts";
import {pruneSimple, type ApiGraph} from "../lib/simple.ts";
import {pruneFace} from "../lib/face.ts";
import {applyModel, DEFAULT_MODEL, SMALL_ENCODER} from "../lib/model.ts";

const box = {frame: 12, x: 0.2, y: 0.3, width: 0.4, height: 0.2};
const load = (name: string): ApiGraph => JSON.parse(readFileSync(new URL(`../workflows/${name}.api.json`, import.meta.url), "utf8"));
const settings = {role: "", resolution: "480p" as const, motion: 512 as const, hatFix: false, noLipSync: false,
                  margin: "normal" as const, target: "person", seed: 42, clipSeconds: 6};

function acyclic(graph: ApiGraph) {
  const seen = new Set<string>(), active = new Set<string>();
  function visit(id: string) {
    if (seen.has(id)) return;
    assert.ok(graph[id], "Missing node " + id); assert.ok(!active.has(id), "Cycle " + id);
    active.add(id);
    for (const v of Object.values(graph[id].inputs)) if (Array.isArray(v) && v.length === 2 && typeof v[0] === "string" && typeof v[1] === "number") visit(v[0]);
    active.delete(id); seen.add(id);
  }
  Object.keys(graph).forEach(visit);
}

test("protected-object selection is validated at the API boundary", () => {
  assert.deepEqual(parseProtectedObject(JSON.stringify(box)), box);
  assert.equal(parseProtectedObject(null), undefined);
  for (const changed of [{frame: -1}, {frame: 1.1}, {x: Infinity}, {x: -0.1}, {width: 0}, {x: 0.9, width: 0.5}]) {
    assert.throws(() => parseProtectedObject({...box, ...changed}));
  }
  assert.notEqual(protectionSuffix(box), protectionSuffix({...box, frame: 13}));
});

test("Simple tracks the full selection once, slices by clip, protects motion reference, inpainting and final RGB", () => {
  const graph = pruneSimple(load("simple"), {...settings, preserveMouth: true, protectedObject: box});
  assert.ok(!graph.keep_source_mouth);
  assert.deepEqual(graph.keep_foreground_track.inputs.images, ["5", 0]);
  assert.deepEqual(graph.keep_foreground_slice.inputs.state, ["29", 0]);
  assert.deepEqual(graph["55"].inputs.mask, ["keep_foreground_exclude", 0]);
  assert.deepEqual(graph["41"].inputs.mask, ["keep_foreground_motion_exclude", 0]);
  assert.deepEqual(graph["63"].inputs.images, ["keep_foreground", 0]);
  assert.deepEqual(graph.keep_foreground.inputs.source, ["31", 0]);
  assert.equal(graph.keep_foreground.inputs.expand, 0);
  applyModel(graph, {...DEFAULT_MODEL, textEncoder: SMALL_ENCODER, cacheMode: "v3"});
  assert.equal(graph["23"].class_type, "OpenJutsu3CheckpointLoader");
  assert.equal(graph.keep_foreground_track.class_type, "OpenJutsuTrackForeground");
  assert.equal(graph["16"].inputs.strength_model, 1);
  acyclic(graph);
});

test("custom source crops are tracked in the same space as the generator", () => {
  const graph = pruneSimple(load("simple"), {...settings, resolution: {width: 512, height: 512}, protectedObject: box});
  assert.deepEqual(graph.keep_foreground_track.inputs.images, ["custom_size", 0]);
  assert.deepEqual(graph.keep_foreground_size.inputs.image, ["5", 0]);
  acyclic(graph);
});

test("Face mode protects the selected object after stitching without retaining the whole mouth", () => {
  const graph = pruneFace(load("face"), {style: "photo", seed: 0, chunkSeconds: 6.5, preserveMouth: true, protectedObject: box});
  assert.ok(!graph.keep_source_mouth);
  assert.deepEqual(graph.keep_foreground_track.inputs.images, ["1", 0]);
  assert.deepEqual(graph.keep_foreground.inputs.generated, ["29", 0]);
  assert.deepEqual(graph.keep_foreground.inputs.source, ["1", 0]);
  acyclic(graph);
});
