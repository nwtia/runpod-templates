import assert from "node:assert/strict";
import test from "node:test";
import {proxyTransfer, submissionTimeout} from "../lib/proxy-transfer.ts";

function delayed(delay: number): typeof fetch {
  return ((_input, init) => new Promise<Response>((resolve, reject) => {
    const timer = setTimeout(() => resolve(new Response("ok")), delay);
    init?.signal?.addEventListener("abort", () => {clearTimeout(timer); reject(init.signal!.reason);}, {once:true});
  })) as typeof fetch;
}

test("large multipart transfers get a longer deadline than ordinary requests", async () => {
  const send = proxyTransfer(delayed(100), 25, 1000);
  const form = new FormData(); form.set("file", new Blob(["neutral fixture"]), "fixture.bin");
  const result = await send("http://127.0.0.1/assets", {body:form, method:"POST", signal:AbortSignal.timeout(1000)});
  assert.equal(await result.text(), "ok");
  await assert.rejects(send("http://127.0.0.1/jobs", {method:"POST", signal:AbortSignal.timeout(1000)}), /timeout/i);
});

test("uploads cannot redirect and explicitly untimed event streams remain untimed", async () => {
  let options: RequestInit | undefined;
  const send = proxyTransfer((async (_input, init) => {options=init; return new Response("ok");}) as typeof fetch);
  const form = new FormData(); form.set("file", "fixture");
  await send("http://127.0.0.1/assets", {body:form, method:"POST"});
  assert.equal(options?.redirect, "error"); assert.ok(options?.signal);
  await send("http://127.0.0.1/events", {headers:{Accept:"text/event-stream"}});
  assert.equal(options?.signal, undefined);
  const controller = new AbortController();
  await send("http://127.0.0.1/events", {headers:{Accept:"text/event-stream"}, signal:controller.signal});
  assert.equal(options?.signal, controller.signal);
});

test("a caller's cancellation is preserved during transfer", async () => {
  const controller = new AbortController();
  const send = proxyTransfer(delayed(500),1000,1000);
  const form = new FormData(); form.set("file", "fixture");
  const result = send("http://127.0.0.1/assets",{body:form,method:"POST",signal:controller.signal});
  controller.abort(new Error("caller canceled"));
  await assert.rejects(result,/caller canceled/);
});

test("timeout messages identify the phase and never advise blindly resubmitting an uncertain job", () => {
  const error = new DOMException("The operation was aborted due to timeout", "TimeoutError");
  assert.match(submissionTimeout(error,"gpu")!,/before any generation/);
  assert.match(submissionTimeout(error,"upload")!,/file transfer.*before any generation/);
  assert.match(submissionTimeout(error,"submit")!,/may already exist/);
  assert.equal(submissionTimeout(new Error("Missing model"),"submit"),null);
});
