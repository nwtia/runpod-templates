export const UPLOAD_TIMEOUT_MS = 300_000;
export const REQUEST_TIMEOUT_MS = 30_000;

// The SDK's outer deadline must also allow large uploads. Explicitly untimed
// SSE requests have no signal and retain that behavior.
export function proxyTransfer(fetcher: typeof fetch = fetch, requestTimeout = REQUEST_TIMEOUT_MS, uploadTimeout = UPLOAD_TIMEOUT_MS): typeof fetch {
  return (input, init) => {
    const uploading = init?.body instanceof FormData;
    const headers = new Headers(init?.headers ?? (input instanceof Request ? input.headers : undefined));
    const streaming = headers.get("accept")?.includes("text/event-stream");
    const deadline = uploading ? AbortSignal.timeout(uploadTimeout)
      : !streaming && init?.signal ? AbortSignal.timeout(requestTimeout) : undefined;
    const signal = deadline && init?.signal ? AbortSignal.any([init.signal, deadline]) : deadline ?? init?.signal;
    return fetcher(input, {...init, signal, ...(uploading ? {redirect: "error" as const} : {})});
  };
}

export function submissionTimeout(error: unknown, phase: "gpu" | "upload" | "submit") {
  const name = error instanceof Error ? error.name : "";
  const message = error instanceof Error ? error.message : "";
  if (!/timeout|timed out/i.test(name + " " + message)) return null;
  if (phase === "gpu") return "The GPU memory check timed out before any generation was submitted. Check the other ComfyUI, then retry.";
  if (phase === "upload") return "The file transfer to ComfyUI timed out before any generation was submitted. Refresh Openjutsu and retry the upload.";
  return "ComfyUI did not confirm the submission in time. Check Recent jobs before retrying: the generation may already exist.";
}
