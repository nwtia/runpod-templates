import type { ApiGraph } from "./simple.ts";

export function keepSourceMouth(graph: ApiGraph, source: unknown, generated: unknown, checkpoint?: string) {
  const key = "keep_source_mouth";
  if (!checkpoint) {
    checkpoint = key + "_model";
    graph[checkpoint] = { class_type: "CheckpointLoaderSimple", inputs: { ckpt_name: "sam3.1_multiplex_fp16.safetensors" } };
  }
  graph[key + "_text"] = { class_type: "CLIPTextEncode", inputs: { clip: [checkpoint, 1], text: "mouth" } };
  graph[key + "_size"] = { class_type: "ImageScaleToMaxDimension", inputs: { image: source, largest_size: 1008, upscale_method: "area" } };
  graph[key + "_track"] = { class_type: "SAM3_VideoTrack", inputs: {
    model: [checkpoint, 0], images: [key + "_size", 0], conditioning: [key + "_text", 0],
    detection_threshold: 0.25, max_objects: 0, detect_interval: 1,
  } };
  graph[key] = { class_type: "OpenJutsuPreserveMouth", inputs: {
    source, generated, track_data: [key + "_track", 0], expand: 3, feather: 2,
  } };
  const sourceEncoder = Object.values(graph).find(node => node.class_type === "MiniMaxH3FantasticVideoEditLatent");
  if (sourceEncoder) {
    graph[key + "_exclude"] = { class_type: "OpenJutsuExcludeMouth", inputs: {
      editable_mask: sourceEncoder.inputs.mask, track_data: [key + "_track", 0],
    } };
    sourceEncoder.inputs.mask = [key + "_exclude", 0];
  }
  return [key, 0];
}
