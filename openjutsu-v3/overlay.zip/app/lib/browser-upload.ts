import { needsChunkedUpload, postChunkedUpload } from "./chunked-upload.ts";

// Keep small uploads independent of disk-backed File handles while bounding browser memory.
export const SNAPSHOT_BUDGET = 32 * 1024 * 1024;

export async function prepareUpload(form: FormData, budget = SNAPSHOT_BUDGET) {
  const stable = new FormData();
  for (const [name, value] of form) {
    if (typeof value === "string") {
      stable.append(name, value);
      continue;
    }
    try {
      if (value.size <= budget) {
        const bytes = await value.arrayBuffer();
        stable.append(name, new Blob([bytes], { type: value.type }), value.name);
        budget -= value.size;
      } else {
        // Large videos keep streaming; check access before beginning the request.
        await value.slice(0, 1).arrayBuffer();
        stable.append(name, value);
      }
    } catch {
      throw new Error(`The selected ${name === "video" ? "video" : "photo"} can no longer be read. Select it again, then retry Generate.`);
    }
  }
  return stable;
}

export async function postSetup(selection: unknown) {
  const body = JSON.stringify(selection);
  for (let attempt = 0; ; attempt++) {
    try {
      return await fetch("/api/setup", {
        method: "POST", credentials: "same-origin", cache: "no-store",
        headers: { "Content-Type": "application/json" }, body,
      });
    } catch (error) {
      if (!(error instanceof TypeError)) throw error;
      if (attempt === 1) throw new Error("Network error while checking setup. Reload Openjutsu and check the Tailscale connection.");
      // This check creates no job and can safely be retried after a brief disconnect.
      await new Promise((resolve) => setTimeout(resolve, 350));
    }
  }
}

export async function postUpload(form: FormData) {
  const stable = await prepareUpload(form);
  if (needsChunkedUpload(stable)) return postChunkedUpload(stable);
  try {
    return await fetch("/api/jobs", { method: "POST", credentials: "same-origin", body: stable });
  } catch (error) {
    if (!(error instanceof TypeError)) throw error;
    // A lost response may still have created a job: never blindly submit twice.
    throw new Error("Network error while uploading files. The job status could not be confirmed. Check Recent jobs, then reselect the video and photos before retrying.");
  }
}
