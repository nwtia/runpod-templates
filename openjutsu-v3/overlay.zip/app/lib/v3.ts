import type { ApiGraph } from "./simple.ts";

// Change node implementations only. Their inputs, links and inference settings stay intact.
export function applyV3Caching(graph: ApiGraph) {
  const markVae = (link: unknown) => {
    if (!Array.isArray(link)) return;
    const loader = graph[String(link[0])];
    if (loader?.class_type === "VAELoader") loader.class_type = "OpenJutsu3VAELoader";
  };
  for (const node of Object.values(graph)) {
    if (["SAM3_VideoTrack", "OpenJutsuTrackForeground"].includes(node.class_type)) {
      const link = node.inputs.model;
      const loader = Array.isArray(link) ? graph[String(link[0])] : undefined;
      if (loader?.class_type === "CheckpointLoaderSimple") loader.class_type = "OpenJutsu3CheckpointLoader";
      if (node.class_type === "SAM3_VideoTrack") node.class_type = "OpenJutsu3VideoTrackCached";
    }
    if (node.class_type === "MiniMaxH3ReferenceToVideo") {
      const link = node.inputs.clip;
      let loader = Array.isArray(link) ? graph[String(link[0])] : undefined;
      if (loader?.class_type === "ClipProjApply") {
        loader.class_type = "OpenJutsu3ClipProjApply";
        const source = loader.inputs.clip;
        loader = Array.isArray(source) ? graph[String(source[0])] : undefined;
      }
      if (loader?.class_type === "CLIPLoader") loader.class_type = "OpenJutsu3CLIPLoader";
      markVae(node.inputs.vae);
      markVae(node.inputs.audio_vae);
      node.class_type = "OpenJutsu3ReferenceCached";
    }
    if (node.class_type === "MiniMaxH3FantasticVideoEditLatent") {
      markVae(node.inputs.vae);
      markVae(node.inputs.audio_vae);
      node.class_type = "OpenJutsu3EditLatentCached";
    }
  }
}
