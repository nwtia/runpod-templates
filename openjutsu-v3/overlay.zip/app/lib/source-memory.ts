// VHS materializes the selected source as RGB float32 at 24 fps before H3 splits it.
// This is a lower bound: tracking, masks and model weights need additional RAM.
export const SOURCE_MEMORY_BUDGET = 8 * 1024 ** 3;
export function sourceBytes(width: number, height: number, seconds: number) {
  if (![width,height,seconds].every(Number.isFinite) || width <= 0 || height <= 0 || seconds <= 0) return 0;
  return Math.ceil(seconds * 24) * width * height * 3 * 4;
}
export function initialSourceLength(width: number, height: number, duration: number) {
  return sourceBytes(width,height,duration) > SOURCE_MEMORY_BUDGET ? Math.min(duration,6,Math.floor(SOURCE_MEMORY_BUDGET / (width * height * 3 * 4 * 24) * 10) / 10) : duration;
}
export function sourceMemoryError(width: number, height: number, seconds: number) {
  const bytes=sourceBytes(width,height,seconds);
  return bytes > SOURCE_MEMORY_BUDGET
    ? `This selection needs at least ${(bytes / 1024 ** 3).toFixed(1)} GiB of RAM just to load the source. Choose a shorter part (at most ${Math.max(0,Math.floor(SOURCE_MEMORY_BUDGET / (width * height * 3 * 4 * 24)))} s at this size). Generation clip length does not limit source loading.`
    : null;
}
