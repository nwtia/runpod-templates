// Only a configured local peer is contacted. Never interrupts a running render.
export async function releaseIdleGpuPeer(peer = process.env.OPENJUTSU_GPU_PEER, fetcher: typeof fetch = fetch) {
  if (!peer) return;
  const base = new URL(peer);
  if (base.protocol !== "http:" || !["127.0.0.1", "localhost"].includes(base.hostname) || base.username || base.password) {
    throw new Error("OPENJUTSU_GPU_PEER must be a local ComfyUI URL.");
  }
  let response: Response;
  try {
    response = await fetcher(new URL("/queue", base), {signal: AbortSignal.timeout(8000), redirect: "error"});
  } catch (error) {
    const code = (error as {cause?: {code?: string}}).cause?.code;
    if (code === "ECONNREFUSED") return;
    throw new Error("Could not check the other local ComfyUI. Check it before starting another GPU job.");
  }
  if (!response.ok) throw new Error("The other local ComfyUI could not report its queue.");
  const queue = await response.json();
  if (!Array.isArray(queue.queue_running) || !Array.isArray(queue.queue_pending)) throw new Error("The other ComfyUI returned an invalid queue.");
  if (queue.queue_running.length || queue.queue_pending.length) throw new Error("Another ComfyUI render is using this GPU. Wait for it to finish before generating here.");
  const freed = await fetcher(new URL("/free", base), {method: "POST", headers: {"Content-Type": "application/json"},
    body: JSON.stringify({unload_models: true, free_memory: true}), signal: AbortSignal.timeout(8000), redirect: "error"});
  if (!freed.ok) throw new Error("The other ComfyUI could not release its idle GPU cache.");
  // ComfyUI handles the flag asynchronously in its worker's idle cycle.
  for (let attempt = 0; attempt < 10; attempt++) {
    const response = await fetcher(new URL("/system_stats", base), {signal: AbortSignal.timeout(8000), redirect: "error"});
    if (!response.ok) throw new Error("Could not confirm that the other ComfyUI released its GPU cache.");
    const stats = await response.json();
    if (Array.isArray(stats.devices) && stats.devices.every((device: {torch_vram_total?: number}) =>
      typeof device.torch_vram_total === "number" && device.torch_vram_total < 512 * 1024 ** 2)) return;
    await new Promise(resolve => setTimeout(resolve, 500));
  }
  throw new Error("The other ComfyUI still holds GPU memory. Wait for it to release its cache before generating here.");
}
