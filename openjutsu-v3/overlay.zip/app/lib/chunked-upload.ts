// Byte-preserving transport for large multipart uploads through the RunPod HTTP proxy.
const LARGE_UPLOAD = 32 * 1024 * 1024;
const MAX_UPLOAD = 2 * 1024 ** 3;
const PREFIX = "/__openjutsu/uploads";

async function retry(url: string, init?: RequestInit) {
  for (let attempt = 0; ; attempt++) {
    try {
      const response = await fetch(url, { ...init, credentials: "same-origin", cache: "no-store" });
      if (response.status >= 500 && attempt < 2) {
        await response.body?.cancel();
      } else return response;
    } catch (error) {
      if (!(error instanceof TypeError) || attempt >= 2) throw error;
    }
    await new Promise((resolve) => setTimeout(resolve, 400 * (attempt + 1)));
  }
}

async function checked(response: Response) {
  if (!response.ok) {
    let message = `Upload failed (HTTP ${response.status}).`;
    try { const data = await response.json(); if (typeof data.error === "string") message = data.error; } catch {}
    throw new Error(message);
  }
  return response;
}

function progress(sent: number, total: number) {
  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("openjutsu-upload-progress", { detail: { sent, total } }));
  }
}

export function uploadBytes(form: FormData) {
  let bytes = 0;
  for (const value of form.values()) if (typeof value !== "string") bytes += value.size;
  return bytes;
}

export function needsChunkedUpload(form: FormData) { return uploadBytes(form) > LARGE_UPLOAD; }

export async function postChunkedUpload(form: FormData) {
  const filesBytes = uploadBytes(form);
  if (filesBytes >= MAX_UPLOAD) throw new Error("Video and photos must total less than 2 GiB.");
  const serialized = new Response(form);
  const contentType = serialized.headers.get("Content-Type");
  const clientId = Array.from(crypto.getRandomValues(new Uint8Array(16)), (byte) => byte.toString(16).padStart(2, "0")).join("");
  const initialized = await checked(await retry(PREFIX, {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ contentType, filesBytes, uploadId: clientId }),
  }));
  const { uploadId, chunkBytes } = await initialized.json();
  if (uploadId !== clientId || chunkBytes !== 8 * 1024 * 1024) {
    throw new Error("Unexpected large-upload protocol. Reload Openjutsu before retrying.");
  }
  const reader = serialized.body!.getReader();
  let buffer = new Uint8Array(chunkBytes), used = 0, part = 0, sent = 0;
  const put = async () => {
    const bytes = buffer.slice(0, used);
    const digest = await crypto.subtle.digest("SHA-256", bytes);
    const sha = Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, "0")).join("");
    await checked(await retry(`${PREFIX}/${uploadId}/${part}`, {
      method: "PUT", headers: { "Content-Type": "application/octet-stream", "Upload-Sha256": sha }, body: bytes,
    }));
    part++; sent += used; used = 0;
    progress(sent, filesBytes);
  };
  progress(0, filesBytes);
  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      let offset = 0;
      while (offset < value.length) {
        const count = Math.min(buffer.length - used, value.length - offset);
        buffer.set(value.subarray(offset, offset + count), used);
        offset += count; used += count;
        if (used === buffer.length) await put();
      }
    }
    if (used) await put();
  } catch (error) {
    try { await fetch(`${PREFIX}/${uploadId}/cancel`, { method: "DELETE", credentials: "same-origin" }); } catch {}
    throw new Error("Video upload interrupted before job submission. Select the files again and retry. " + (error instanceof Error ? error.message : ""));
  } finally { await reader.cancel(); }
  // Only the transport is retried. The server records a single commit before submitting a job.
  const commit = { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ parts: part, bytes: sent }) };
  let response: Response;
  try { response = await retry(`${PREFIX}/${uploadId}/commit`, commit); }
  catch { response = await retry(`${PREFIX}/${uploadId}/status`); }
  for (;;) {
    if (response.status !== 202 || (await response.clone().json()).uploadPending !== true) return response;
    await new Promise((resolve) => setTimeout(resolve, 1000));
    response = await retry(`${PREFIX}/${uploadId}/status`);
    const state = response.status === 202 ? await response.clone().json() : null;
    if (state?.state === "uploading") response = await retry(`${PREFIX}/${uploadId}/commit`, commit);
  }
}
