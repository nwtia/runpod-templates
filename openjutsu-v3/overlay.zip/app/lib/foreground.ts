import type { ApiGraph } from "./simple.ts";

export type ProtectedObject = {frame: number; x: number; y: number; width: number; height: number};
export function parseProtectedObject(value: unknown): ProtectedObject | undefined {
  if (value === null || value === undefined || value === "") return undefined;
  const box = typeof value === "string" ? JSON.parse(value) : value;
  if (!box || !Number.isInteger(box.frame) || box.frame < 0
      || ![box.x, box.y, box.width, box.height].every(Number.isFinite)
      || box.x < 0 || box.y < 0 || box.x >= 1 || box.y >= 1 || box.width <= 0 || box.height <= 0
      || box.x + box.width > 1.000001 || box.y + box.height > 1.000001) throw new Error("Draw the protected object inside the selected video section.");
  return {frame: box.frame, x: box.x, y: box.y, width: box.width, height: box.height};
}

export function protectionSuffix(selection: ProtectedObject) {
  let hash = 14695981039346656037n;
  for (const ch of JSON.stringify(selection)) hash = BigInt.asUintN(64, (hash ^ BigInt(ch.charCodeAt(0))) * 1099511628211n);
  return "_foreground1_" + hash.toString(16);
}

export function keepForeground(graph: ApiGraph, source: unknown, generated: unknown,
  wholeSource: unknown, originalSource: unknown, selection: ProtectedObject, checkpoint?: string, state?: unknown) {
  const key = "keep_foreground";
  if (!checkpoint) {
    checkpoint = key + "_model";
    graph[checkpoint] = {class_type: "CheckpointLoaderSimple", inputs: {ckpt_name: "sam3.1_multiplex_fp16.safetensors"}};
  }
  graph[key + "_size"] = {class_type: "GetImageSize", inputs: {image: originalSource}};
  graph[key + "_track"] = {class_type: "OpenJutsuTrackForeground", inputs: {
    images: wholeSource, model: [checkpoint, 0], selection: JSON.stringify(selection),
    original_width: [key + "_size", 0], original_height: [key + "_size", 1],
  }};
  let track: unknown = [key + "_track", 0];
  if (state) {
    graph[key + "_slice"] = {class_type: "OpenJutsuRegionTrackSlice", inputs: {track_data: track, state}};
    track = [key + "_slice", 0];
  }
  graph[key] = {class_type: "OpenJutsuPreserveRegion", inputs: {source, generated, track_data: track, expand: 0, feather: 1}};
  const encoder = Object.values(graph).find(n => n.class_type === "MiniMaxH3FantasticVideoEditLatent");
  if (encoder) {
    graph[key + "_exclude"] = {class_type: "OpenJutsuExcludeRegion", inputs: {editable_mask: encoder.inputs.mask, track_data: track}};
    encoder.inputs.mask = [key + "_exclude", 0];
  }
  // Tracking must finish before H3's large encoders/models are loaded. Protecting the
  // motion reference also keeps the selected prop visible instead of turning it grey.
  const mannequin = Object.values(graph).find(n => n.class_type === "H3GreyMannequins");
  if (mannequin) {
    graph[key + "_motion_exclude"] = {class_type: "OpenJutsuExcludeRegion", inputs: {
      editable_mask: mannequin.inputs.mask, track_data: track,
    }};
    mannequin.inputs.mask = [key + "_motion_exclude", 0];
  }
  return [key, 0];
}
