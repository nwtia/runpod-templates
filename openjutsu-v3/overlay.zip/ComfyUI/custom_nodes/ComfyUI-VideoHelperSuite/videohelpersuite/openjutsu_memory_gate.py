"""OpenJutsu local guard: VHS images are uncompressed float32, not compressed pixels."""
MAX_IMAGE_BYTES = 8 * 1024 ** 3

def image_frame_limit(width, height, alpha, available_bytes, requested_frames):
    bytes_per_frame = int(width) * int(height) * (4 if alpha else 3) * 4
    if bytes_per_frame <= 0: raise RuntimeError('Invalid source video dimensions.')
    # Leave headroom for fromiter growth, masks, resized copies and model weights.
    budget = min(MAX_IMAGE_BYTES, max(0, int(available_bytes) // 2))
    maximum = budget // bytes_per_frame
    if maximum < 1 or requested_frames > maximum:
        gib = requested_frames * bytes_per_frame / 1024 ** 3
        raise RuntimeError(
            f'This source selection needs at least {gib:.1f} GiB of RAM for decoded images. '
            'Choose a shorter Part to use in OpenJutsu. Generation clip length does not limit '
            'source loading. No frames have been discarded or resized automatically.')
    return maximum
