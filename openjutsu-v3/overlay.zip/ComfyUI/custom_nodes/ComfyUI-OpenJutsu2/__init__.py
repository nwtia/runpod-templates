"""OpenJutsu 2.0: exact caption reuse; native ComfyUI model loading and inference."""
import os
import hashlib
import importlib.metadata
import logging
from pathlib import Path
import sys
import torch
import nodes
import folder_paths
import comfyui_version
from comfy_api.latest import ComfyExtension, io
from comfy_extras.nodes_textgen import TextGenerate
from .cache_engine import CaptionCache, eligible

CACHE = CaptionCache(os.environ.get('OPENJUTSU_V2_CACHE', '/workspace/openjutsu/cache/captions-v2'))
source_hash = hashlib.sha256()
base = Path(folder_paths.base_path)
for p in [Path(__file__), Path(__file__).with_name('cache_engine.py'),
          base/'comfy_extras/nodes_textgen.py', base/'comfy/sd.py', base/'comfy/ops.py',
          base/'comfy/model_management.py', base/'comfy/model_patcher.py',
          *sorted((base/'comfy/text_encoders').glob('*.py')),
          *sorted((base/'comfy/ldm/qwen3vl').glob('*.py')),
          *sorted((base/'custom_nodes/ComfyUI-ClipProj').rglob('*.py'))]:
    if p.is_file(): source_hash.update(p.read_bytes())
SOFTWARE = {'source': source_hash.hexdigest(), 'comfy': comfyui_version.__version__,
    'torch': torch.__version__, 'launch_args': sys.argv[1:],
    'tf32': torch.backends.cuda.matmul.allow_tf32,
    'cudnn_tf32': torch.backends.cudnn.allow_tf32,
    'matmul_precision': torch.get_float32_matmul_precision()}
SOFTWARE['packages'] = {}
for name in ('comfy-kitchen', 'comfy-aimdo', 'safetensors', 'numpy'):
    try: SOFTWARE['packages'][name] = importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError: SOFTWARE['packages'][name] = 'unavailable'

class OpenJutsuDescriberLoader(io.ComfyNode):
    @classmethod
    def define_schema(cls):
        config = nodes.CLIPLoader.INPUT_TYPES()
        return io.Schema(node_id='OpenJutsuDescriberLoader', display_name='OpenJutsu 2.0 Describer', category='OpenJutsu 2.0',
            inputs=[io.Combo.Input('clip_name', options=config['required']['clip_name'][0]),
                    io.Combo.Input('type', options=config['required']['type'][0]),
                    io.Combo.Input('device', options=['default', 'cpu'], default='default', optional=True)],
            outputs=[io.Clip.Output()])

    @classmethod
    def execute(cls, clip_name, type='stable_diffusion', device='default'):
        clip, = nodes.CLIPLoader().load_clip(clip_name, type, device)
        path = folder_paths.get_full_path_or_raise('text_encoders', clip_name)
        try:
            marker = CACHE.fingerprint(path)
            marker.update(loader_type=type, device=str(clip.patcher.load_device))
            clip._openjutsu_caption_source = marker
        except (OSError, RuntimeError) as exc:
            logging.warning('[OpenJutsu 2.0] model checksum unavailable; caption cache bypassed: %s', exc)
        return io.NodeOutput(clip)

class OpenJutsuTextGenerateCached(TextGenerate):
    @classmethod
    def define_schema(cls):
        schema = super().define_schema()
        schema.node_id = 'OpenJutsuTextGenerateCached'
        schema.display_name = 'OpenJutsu 2.0 Generate Text (exact cache)'
        schema.category = 'OpenJutsu 2.0'
        schema.is_deprecated = False
        return schema

    @classmethod
    def execute(cls, clip, prompt, max_length, sampling_mode, image=None, thinking=False, use_default_template=True,
                video=None, audio=None, mtp='auto', system_prompt='', images=None, videos=None, audios=None):
        parameters = dict(prompt=prompt, max_length=max_length, sampling_mode=sampling_mode, image=image,
            thinking=thinking, use_default_template=use_default_template, video=video, audio=audio,
            mtp=mtp, system_prompt=system_prompt, images=images, videos=videos, audios=audios)
        key = None
        identity = eligible(clip, sampling_mode)
        # External embedding files are not covered by the model fingerprint.
        if identity is not None and 'embedding:' not in (prompt + system_prompt).lower():
            try: key = CACHE.key(identity, parameters, SOFTWARE)
            except (TypeError, ValueError, RuntimeError) as exc:
                logging.info('[OpenJutsu 2.0] caption cache bypassed: %s', exc)
        def compute():
            result = TextGenerate.execute(clip=clip, **parameters)
            if result.ui or result.expand or result.block_execution or not CaptionCache._valid(result.args): return result
            return result.args
        result = CACHE.run(key, compute)
        return result if isinstance(result, io.NodeOutput) else io.NodeOutput(*result)

class OpenJutsuExtension(ComfyExtension):
    async def get_node_list(self):
        return [OpenJutsuDescriberLoader, OpenJutsuTextGenerateCached]

async def comfy_entrypoint():
    return OpenJutsuExtension()
