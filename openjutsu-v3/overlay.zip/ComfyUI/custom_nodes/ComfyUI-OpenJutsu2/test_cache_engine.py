import importlib.util
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
import torch

spec=importlib.util.spec_from_file_location('caption_cache_engine',Path(__file__).with_name('cache_engine.py'))
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
CaptionCache=module.CaptionCache

class ExactCaptionCacheTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='openjutsu2-cache-')
        self.root=Path(self.temp.name)
        self.cache=CaptionCache(self.root/'cache')
        self.file=self.root/'encoder.safetensors';self.file.write_bytes(b'weights-v1')
        marker=self.cache.fingerprint(self.file)
        marker.update(loader_type='stable_diffusion',device='cuda:0')
        self.clip=SimpleNamespace(_openjutsu_caption_source=marker,layer_idx=None,tokenizer_options={},
            patcher=SimpleNamespace(patches={},forced_hooks=None,model_options={}))
        self.params={'prompt':'Describe this image','image':torch.zeros(1,2,2,3),'max_length':160,
            'sampling_mode':{'sampling_mode':'off'},'thinking':False,'mtp':'auto'}

    def tearDown(self): self.temp.cleanup()

    def key(self, params=None, software=None):
        return self.cache.key(module.eligible(self.clip,{'sampling_mode':'off'}),params or self.params,software or {'native':'v1'})

    def test_persisted_hit_returns_both_original_strings_without_inference(self):
        key=self.key();calls=[]
        def compute(): calls.append(1);return ('An officer in a navy uniform.','Exact reasoning é.')
        expected=self.cache.run(key,compute)
        fresh=CaptionCache(self.cache.root)
        self.assertEqual(fresh.run(key,compute),expected)
        self.assertEqual(len(calls),1)
        self.assertEqual(fresh.hits,1)

    def test_same_pixel_values_ignore_tensor_storage_identity(self):
        copied={**self.params,'image':self.params['image'].clone()}
        self.assertEqual(self.key(),self.key(copied))

    def test_pixel_change_invalidates_caption(self):
        image=self.params['image'].clone();image[0,0,0,0]=1
        self.assertNotEqual(self.key(),self.key({**self.params,'image':image}))

    def test_prompt_and_generation_options_are_part_of_the_key(self):
        for change in [{'prompt':'A different role'},{'max_length':40},{'thinking':True},{'mtp':'off'}]:
            self.assertNotEqual(self.key(),self.key({**self.params,**change}))

    def test_changed_model_file_bypasses_stale_loaded_identity(self):
        original=self.cache.fingerprint(self.file)['sha256']
        self.file.write_bytes(b'new-different-weights-v2')
        self.assertIsNone(module.eligible(self.clip,{'sampling_mode':'off'}))
        self.assertNotEqual(original,self.cache.fingerprint(self.file)['sha256'])

    def test_sampling_and_clip_patches_bypass_cache(self):
        self.assertIsNone(module.eligible(self.clip,{'sampling_mode':'on','seed':42}))
        self.clip.patcher.patches={'weight':object()}
        self.assertIsNone(module.eligible(self.clip,{'sampling_mode':'off'}))
        calls=[]
        self.cache.run(None,lambda:calls.append(1) or ('sample1',''))
        self.cache.run(None,lambda:calls.append(1) or ('sample2',''))
        self.assertEqual(len(calls),2)

    def test_native_implementation_or_runtime_change_invalidates_cache(self):
        self.assertNotEqual(self.key(),self.key(software={'native':'v2'}))

    def test_corrupt_cache_falls_back_to_native_generation(self):
        key=self.key();self.cache.run(key,lambda:('first',''))
        path=self.cache.entries/(key+'.json')
        path.write_text('{bad json')
        self.assertEqual(self.cache.run(key,lambda:('recomputed','')),('recomputed',''))
        data=json.loads(path.read_text());data['outputs']=['tampered',''];path.write_text(json.dumps(data))
        self.assertEqual(self.cache.run(key,lambda:('verified new','')),('verified new',''))

    def test_unsupported_options_do_not_get_an_ambiguous_key(self):
        with self.assertRaises(TypeError): self.key({**self.params,'callback':lambda:None})

    def test_integer_and_string_values_cannot_share_a_cache_key(self):
        self.assertNotEqual(self.key({**self.params,'options':{'value':160}}),
                            self.key({**self.params,'options':{'value':'integer:160'}}))

    def test_non_text_native_result_is_not_written(self):
        key=self.key();sentinel=object()
        self.assertIs(self.cache.run(key,lambda:sentinel),sentinel)
        self.assertFalse((self.cache.entries/(key+'.json')).exists())

    def test_cache_disk_failure_preserves_successful_native_output(self):
        key=self.key()
        def fail(*args): raise OSError('Disk is full')
        self.cache._write=fail
        self.assertEqual(self.cache.run(key,lambda:('original caption','reasoning')),('original caption','reasoning'))

if __name__=='__main__': unittest.main(verbosity=2)
