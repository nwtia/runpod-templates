"""Content-addressed cache of exact greedy captions. No model inference changes."""
import hashlib
import json
import logging
import os
from pathlib import Path
import struct
import tempfile
import time

FORMAT = 1

def signature(path):
    s = Path(path).stat()
    return [s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns]

class CaptionCache:
    def __init__(self, root):
        self.root = Path(root)
        self.models = self.root / 'models'
        self.entries = self.root / 'captions'
        self.hits = self.misses = 0

    @staticmethod
    def _write(path, data):
        path.parent.mkdir(parents=True, exist_ok=True)
        temp = None
        try:
            with tempfile.NamedTemporaryFile('w', dir=path.parent, suffix='.tmp', delete=False, encoding='utf-8') as f:
                temp = f.name
                json.dump(data, f, ensure_ascii=False)
            os.replace(temp, path)
        finally:
            if temp and os.path.exists(temp): os.unlink(temp)

    def fingerprint(self, path):
        path = Path(path).resolve()
        sig = signature(path)
        record = self.models / (hashlib.sha256(str(path).encode()).hexdigest()+'.json')
        try:
            saved = json.loads(record.read_text(encoding='utf-8'))
            if saved['signature'] == sig and len(saved['sha256']) == 64:
                return {'sha256': saved['sha256'], 'signature': sig, 'path': str(path)}
        except (OSError, ValueError, KeyError, TypeError): pass
        h = hashlib.sha256()
        with path.open('rb') as f:
            while chunk := f.read(8*1024**2): h.update(chunk)
        if signature(path) != sig: raise RuntimeError('Encoder file changed during checksum verification')
        result = {'sha256': h.hexdigest(), 'signature': sig, 'path': str(path)}
        self._write(record, result)
        return result

    def prime(self, path, sha256):
        path = Path(path).resolve()
        result = {'sha256': sha256, 'signature': signature(path), 'path': str(path)}
        record = self.models / (hashlib.sha256(str(path).encode()).hexdigest()+'.json')
        self._write(record, result)
        return result

    @staticmethod
    def key(identity, parameters, software):
        import torch
        h = hashlib.sha256()
        def feed(v):
            if v is None: h.update(b'N')
            elif isinstance(v, bool): h.update(b'B1' if v else b'B0')
            elif isinstance(v, int):
                b = str(v).encode('ascii'); h.update(b'I'+str(len(b)).encode()+b':'+b)
            elif isinstance(v, float): h.update(b'F'+struct.pack('!d', v))
            elif isinstance(v, str):
                b = v.encode('utf-8'); h.update(b'S'+str(len(b)).encode()+b':'+b)
            elif isinstance(v, torch.Tensor):
                t = v.detach().cpu().contiguous()
                h.update(b'T'); feed(str(t.dtype)); feed(list(t.shape))
                data = t.view(torch.uint8).numpy().tobytes()
                h.update(str(len(data)).encode()+b':'); h.update(data)
            elif isinstance(v, dict):
                if not all(isinstance(k, str) for k in v): raise TypeError('Non-string key')
                h.update(b'D'); feed(len(v))
                for k in sorted(v): feed(k); feed(v[k])
            elif isinstance(v, (list, tuple)):
                h.update(b'L' if isinstance(v, list) else b'U'); feed(len(v))
                for item in v: feed(item)
            else: raise TypeError('Unsupported cache parameter '+type(v).__name__)
        feed({'format': FORMAT, 'encoder': identity, 'parameters': parameters, 'software': software})
        return h.hexdigest()

    @staticmethod
    def _valid(values):
        return isinstance(values, (list, tuple)) and len(values) == 2 and all(isinstance(v, str) and len(v) <= 2_000_000 for v in values)

    @staticmethod
    def _output_hash(values):
        return hashlib.sha256(json.dumps(values, ensure_ascii=False, separators=(',', ':')).encode()).hexdigest()

    def run(self, key, compute):
        if key is None: return compute()
        path = self.entries / (key+'.json')
        try:
            data = json.loads(path.read_text(encoding='utf-8'))
            values = data['outputs']
            if data['format'] == FORMAT and data['key'] == key and self._valid(values) and data['digest'] == self._output_hash(values):
                self.hits += 1
                logging.info('[OpenJutsu 2.0] caption cache HIT %s', key[:12])
                return tuple(values)
        except (OSError, ValueError, TypeError, KeyError): pass
        self.misses += 1
        logging.info('[OpenJutsu 2.0] caption cache MISS %s', key[:12])
        values = compute()
        if self._valid(values):
            try:
                self._write(path, {'format': FORMAT, 'key': key, 'outputs': values, 'digest': self._output_hash(values)})
                if self.misses % 100 == 0: self.prune()
            except (OSError, ValueError, TypeError) as exc: logging.warning('[OpenJutsu 2.0] caption cache write skipped: %s', exc)
        return values

    def prune(self, maximum=4096):
        files = sorted(self.entries.glob('*.json'), key=lambda p: p.stat().st_mtime)
        for p in files[:-maximum]:
            try: p.unlink()
            except OSError: pass

def eligible(clip, sampling_mode):
    mode = sampling_mode.get('sampling_mode') if isinstance(sampling_mode, dict) else sampling_mode
    if mode != 'off': return None
    marker = getattr(clip, '_openjutsu_caption_source', None)
    if not marker: return None
    patcher = clip.patcher
    if getattr(patcher, 'patches', None) or getattr(patcher, 'forced_hooks', None): return None
    try:
        if signature(marker['path']) != marker['signature']: return None
    except OSError: return None
    return {'sha256': marker['sha256'], 'loader_type': marker['loader_type'], 'device': marker['device'],
        'layer_idx': getattr(clip, 'layer_idx', None), 'tokenizer_options': getattr(clip, 'tokenizer_options', {}),
        'model_options': getattr(patcher, 'model_options', {})}
