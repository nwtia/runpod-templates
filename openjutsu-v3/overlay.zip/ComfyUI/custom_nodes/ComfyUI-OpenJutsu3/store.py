"""Bounded local reuse of node results. JSON + safetensors; no pickle or model patches."""
import hashlib
import json
import logging
import math
import os
from pathlib import Path
import shutil
import struct
import tempfile
import threading
import uuid

import torch
from safetensors.torch import load_file, save_file
from safetensors import SafetensorError

GIB = 1024 ** 3


def digest_file(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        while chunk := f.read(8 * 1024 ** 2):
            h.update(chunk)
    return h.hexdigest()


def signature(path):
    s = Path(path).stat()
    return [s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns]


def key_for(value):
    h = hashlib.sha256()
    def feed(v):
        if v is None:
            h.update(b'N')
        elif type(v) is bool:
            h.update(b'B1' if v else b'B0')
        elif type(v) is int:
            h.update(b'I'); feed(str(v))
        elif type(v) is float:
            if not math.isfinite(v):
                raise TypeError('Non-finite metadata')
            h.update(b'F' + struct.pack('!d', v))
        elif type(v) is str:
            b = v.encode('utf-8')
            h.update(b'S' + str(len(b)).encode() + b':' + b)
        elif type(v) in (list, tuple):
            h.update(b'L' if type(v) is list else b'U'); feed(len(v))
            for item in v:
                feed(item)
        elif type(v) is dict:
            if not all(type(k) is str for k in v):
                raise TypeError('Non-string dictionary key')
            h.update(b'D'); feed(len(v))
            for k in sorted(v):
                feed(k); feed(v[k])
        elif type(v) is torch.Tensor:
            if v.layout != torch.strided:
                raise TypeError('Unsupported tensor layout')
            t = v.detach()
            h.update(b'T'); feed(str(t.dtype)); feed(tuple(t.shape))
            feed(t.numel() * t.element_size())
            if t.numel():
                frames = t.reshape(1) if t.ndim == 0 else t
                row_bytes = max(1, frames[0].numel() * t.element_size())
                step = max(1, 8 * 1024 ** 2 // row_bytes)
                for start in range(0, len(frames), step):
                    chunk = frames[start:start + step].cpu().contiguous()
                    data = memoryview(chunk.reshape(-1).view(torch.uint8).numpy()).cast('B')
                    h.update(data)
        else:
            raise TypeError('Unsupported cache input: ' + type(v).__name__)
    feed(value)
    return h.hexdigest()


def pack(value, nested_type=None):
    tensors = {}
    def visit(v):
        if v is None or type(v) in (str, bool, int):
            return ['scalar', v]
        if type(v) is float and math.isfinite(v):
            return ['scalar', v]
        if type(v) is torch.Tensor:
            # Native conditioning and packed SAM masks normally live on CPU.
            # Do not turn a device-specific result into a persistent GPU cache.
            if v.device.type != 'cpu' or v.layout != torch.strided:
                raise TypeError('Only dense CPU outputs are persisted')
            name = 't' + str(len(tensors))
            tensors[name] = v.detach().contiguous().clone()
            return ['tensor', name]
        if nested_type is not None and type(v) is nested_type:
            return ['nested', [visit(t) for t in v.unbind()]]
        if type(v) in (list, tuple):
            return ['list' if type(v) is list else 'tuple', [visit(t) for t in v]]
        if type(v) is dict and all(type(k) is str for k in v):
            return ['dict', [[k, visit(t)] for k, t in v.items()]]
        raise TypeError('Unsupported cache output: ' + type(v).__name__)
    return visit(value), tensors


def unpack(tree, tensors, nested_type=None):
    kind, body = tree
    if kind == 'scalar' and (body is None or type(body) in (str, bool, int, float)):
        return body
    if kind == 'tensor':
        return tensors[body]
    if kind == 'list':
        return [unpack(t, tensors, nested_type) for t in body]
    if kind == 'tuple':
        return tuple(unpack(t, tensors, nested_type) for t in body)
    if kind == 'dict':
        return {k: unpack(t, tensors, nested_type) for k, t in body}
    if kind == 'nested' and nested_type is not None:
        return nested_type([unpack(t, tensors, nested_type) for t in body])
    raise ValueError('Invalid cache tree')


class Store:
    def __init__(self, root, budget=8 * GIB, reserve=30 * GIB, entry_limit=256 * 1024 ** 2):
        self.root = Path(root)
        self.budget, self.reserve, self.entry_limit = budget, reserve, entry_limit
        self.lock = threading.RLock()

    def write_json(self, path, value):
        path.parent.mkdir(parents=True, exist_ok=True)
        temp = None
        try:
            with tempfile.NamedTemporaryFile('w', dir=path.parent, suffix='.tmp', delete=False, encoding='utf-8') as f:
                temp = f.name
                json.dump(value, f, ensure_ascii=False, allow_nan=False)
            os.replace(temp, path)
        finally:
            if temp and os.path.exists(temp):
                os.unlink(temp)

    def fingerprint(self, path):
        path = Path(path).resolve()
        before = signature(path)
        record = self.root / 'models' / (key_for(str(path)) + '.json')
        try:
            saved = json.loads(record.read_text(encoding='utf-8'))
            if saved['signature'] == before and len(saved['sha256']) == 64:
                return saved
        except (OSError, ValueError, KeyError, TypeError):
            pass
        result = {'path': str(path), 'signature': before, 'sha256': digest_file(path)}
        if signature(path) != before:
            raise RuntimeError('Model changed during fingerprinting')
        try:
            self.write_json(record, result)
        except OSError:
            pass
        return result

    def read(self, namespace, key, nested_type=None):
        directory = self.root / namespace
        try:
            manifest = json.loads((directory / (key + '.json')).read_text(encoding='utf-8'))
            if manifest['format'] != 1 or manifest['key'] != key:
                return None
            blob = manifest['blob']
            if Path(blob).name != blob or not blob.startswith(key + '-') or not blob.endswith('.safetensors'):
                return None
            path = directory / blob
            if path.stat().st_size > self.entry_limit or digest_file(path) != manifest['sha256']:
                return None
            if key_for(manifest['tree']) != manifest['tree_sha256']:
                return None
            result = unpack(manifest['tree'], load_file(str(path), device='cpu'), nested_type)
            os.utime(directory / (key + '.json'), None)
            return result
        except (OSError, ValueError, TypeError, KeyError, RuntimeError, RecursionError, SafetensorError):
            return None

    def write(self, namespace, key, value, nested_type=None):
        tree, tensors = pack(value, nested_type)
        size = sum(t.numel() * t.element_size() for t in tensors.values())
        if size > self.entry_limit or len(json.dumps(tree)) > 8 * 1024 ** 2:
            return
        self.root.mkdir(parents=True, exist_ok=True)
        self.prune(incoming=size)
        if shutil.disk_usage(self.root).free < self.reserve + 2 * size + 1024 ** 2:
            return
        directory = self.root / namespace
        directory.mkdir(exist_ok=True)
        blob = key + '-' + uuid.uuid4().hex + '.safetensors'
        path = directory / blob
        try:
            save_file(tensors, str(path))
            self.write_json(directory / (key + '.json'), {
                'format': 1, 'key': key, 'blob': blob, 'tree': tree,
                'tree_sha256': key_for(tree), 'sha256': digest_file(path)})
        except (OSError, ValueError, TypeError, RuntimeError, SafetensorError):
            path.unlink(missing_ok=True)
            raise
        self.prune()

    def prune(self, incoming=0):
        # Only generated artifacts in these fixed namespaces are eligible for eviction.
        directories = [self.root / n for n in ('tracking', 'conditioning', 'source')]
        blobs = [p for d in directories for p in d.glob('*.safetensors')]
        total = sum(p.stat().st_size for p in blobs)
        manifests = sorted((p for d in directories for p in d.glob('*.json')), key=lambda p: p.stat().st_mtime)
        referenced = set()
        for manifest in manifests:
            try:
                blob = json.loads(manifest.read_text(encoding='utf-8'))['blob']
                if Path(blob).name == blob:
                    referenced.add(manifest.parent / blob)
            except (OSError, ValueError, KeyError, TypeError):
                continue
        for blob in blobs:
            if blob not in referenced:
                total -= blob.stat().st_size
                blob.unlink(missing_ok=True)
        for manifest in manifests:
            if total + incoming <= self.budget:
                break
            try:
                blob = json.loads(manifest.read_text(encoding='utf-8'))['blob']
                if Path(blob).name != blob:
                    continue
                path = manifest.parent / blob
                if path.exists():
                    total -= path.stat().st_size
                    path.unlink()
                manifest.unlink()
            except (OSError, ValueError, KeyError, TypeError):
                continue

    def run(self, namespace, key, compute, nested_type=None):
        if key is None or (self.root / 'disabled').exists():
            return compute()
        with self.lock:
            cached = self.read(namespace, key, nested_type)
            if cached is not None:
                logging.info('[OpenJutsu V3] %s HIT %s', namespace, key[:12])
                return cached
            logging.info('[OpenJutsu V3] %s MISS %s', namespace, key[:12])
            value = compute()
            try:
                self.write(namespace, key, value, nested_type)
            except (OSError, ValueError, TypeError, RuntimeError, SafetensorError) as exc:
                logging.warning('[OpenJutsu V3] cache write skipped: %s', exc)
            return value
