"""OpenJutsu V3: reuse native preprocessing results; inference stays native."""
import os
import hashlib
import importlib.metadata
import logging
from pathlib import Path
import sys

import torch
import nodes
import folder_paths
import comfyui_version
from comfy.nested_tensor import NestedTensor
from comfy_api.latest import ComfyExtension, io
from comfy_extras.nodes_minimax_h3 import MiniMaxH3ReferenceToVideo
from comfy_extras.nodes_sam3 import SAM3_VideoTrack
from .store import Store, key_for, signature

CACHE = Store(os.environ.get('OPENJUTSU_V3_CACHE', '/workspace/openjutsu/cache/v3'))
base = Path(folder_paths.base_path)
h = hashlib.sha256()
sources = [Path(__file__), Path(__file__).with_name('store.py'), base / 'nodes.py',
           base / 'comfy_extras/nodes_sam3.py', base / 'comfy_extras/nodes_minimax_h3.py']
for directory in ('comfy', 'custom_nodes/ComfyUI-ClipProj',
                  'custom_nodes/ComfyUI-Fantastic-MiniMaxH3-PromptBuilder'):
    sources.extend(sorted((base / directory).rglob('*.py')))
for path in sources:
    if path.is_file():
        h.update(str(path.relative_to(base) if path.is_relative_to(base) else path.name).encode())
        h.update(path.read_bytes())
SOFTWARE = {'source': h.hexdigest(), 'comfy': comfyui_version.__version__,
            'torch': str(torch.__version__), 'cuda': torch.version.cuda, 'args': sys.argv[1:],
            'tf32': torch.backends.cuda.matmul.allow_tf32,
            'cudnn_tf32': torch.backends.cudnn.allow_tf32,
            'precision': torch.get_float32_matmul_precision()}
for package in ('comfy-kitchen', 'comfy-aimdo', 'safetensors', 'numpy'):
    try:
        SOFTWARE[package] = importlib.metadata.version(package)
    except importlib.metadata.PackageNotFoundError:
        SOFTWARE[package] = None


def file_identity(folder, name):
    return CACHE.fingerprint(folder_paths.get_full_path_or_raise(folder, name))


def mark(value, files, settings):
    value._openjutsu3_source = {'files': files, 'settings': settings}
    return value


def identity(value):
    if value is None:
        return None
    marker = getattr(value, '_openjutsu3_source', None)
    if marker is None:
        raise TypeError('Untracked model; native path used')
    for file in marker['files']:
        if signature(file['path']) != file['signature']:
            raise TypeError('Model file changed after load')
    patcher = value if hasattr(value, 'model_options') else value.patcher
    if patcher.patches or getattr(patcher, 'forced_hooks', None) or getattr(patcher, 'object_patches', None):
        raise TypeError('Patched model; native path used')
    return {'files': [f['sha256'] for f in marker['files']], 'settings': marker['settings'],
            'options': patcher.model_options,
            'load_device': str(patcher.load_device),
            'layer': getattr(value, 'layer_idx', None),
            'tokenizer': getattr(value, 'tokenizer_options', {}),
            'vae_dtype': str(getattr(value, 'vae_dtype', None))}


def cache_key(namespace, parameters, models):
    try:
        runtime = {'tf32': torch.backends.cuda.matmul.allow_tf32,
                   'cudnn_tf32': torch.backends.cudnn.allow_tf32,
                   'precision': torch.get_float32_matmul_precision(),
                   'deterministic': torch.are_deterministic_algorithms_enabled(),
                   'cudnn_benchmark': torch.backends.cudnn.benchmark,
                   'cudnn_deterministic': torch.backends.cudnn.deterministic}
        return key_for({'namespace': namespace, 'software': SOFTWARE, 'runtime': runtime, 'parameters': parameters,
                        'models': {k: identity(v) for k, v in models.items()}})
    except (OSError, TypeError, ValueError, RuntimeError) as exc:
        logging.info('[OpenJutsu V3] %s bypassed: %s', namespace, exc)
        return None


class OpenJutsu3CheckpointLoader(io.ComfyNode):
    @classmethod
    def define_schema(cls):
        return io.Schema(node_id='OpenJutsu3CheckpointLoader', category='OpenJutsu V3',
                         inputs=[io.Combo.Input('ckpt_name', options=folder_paths.get_filename_list('checkpoints'))],
                         outputs=[io.Model.Output(), io.Clip.Output(), io.Vae.Output()])

    @classmethod
    def execute(cls, ckpt_name):
        file = file_identity('checkpoints', ckpt_name)
        model, clip, vae = nodes.CheckpointLoaderSimple().load_checkpoint(ckpt_name)
        if signature(file['path']) != file['signature']:
            raise RuntimeError('Checkpoint changed while loading; reload it')
        for obj in (model, clip, vae):
            if obj is not None:
                mark(obj, [file], {'loader': 'CheckpointLoaderSimple'})
        return io.NodeOutput(model, clip, vae)


class OpenJutsu3CLIPLoader(io.ComfyNode):
    @classmethod
    def define_schema(cls):
        config = nodes.CLIPLoader.INPUT_TYPES()['required']
        return io.Schema(node_id='OpenJutsu3CLIPLoader', category='OpenJutsu V3', inputs=[
            io.Combo.Input('clip_name', options=config['clip_name'][0]),
            io.Combo.Input('type', options=config['type'][0]),
            io.Combo.Input('device', options=['default', 'cpu'], default='default', optional=True)],
            outputs=[io.Clip.Output()])

    @classmethod
    def execute(cls, clip_name, type='stable_diffusion', device='default'):
        file = file_identity('text_encoders', clip_name)
        clip, = nodes.CLIPLoader().load_clip(clip_name, type, device)
        if signature(file['path']) != file['signature']:
            raise RuntimeError('Encoder changed while loading; reload it')
        return io.NodeOutput(mark(clip, [file], {'loader': 'CLIPLoader', 'type': type, 'device': device}))


class OpenJutsu3VAELoader(io.ComfyNode):
    @classmethod
    def define_schema(cls):
        return io.Schema(node_id='OpenJutsu3VAELoader', category='OpenJutsu V3',
                         inputs=[io.Combo.Input('vae_name', options=nodes.VAELoader.vae_list(None))],
                         outputs=[io.Vae.Output()])

    @classmethod
    def execute(cls, vae_name):
        # Approximate/pixel VAEs keep their original loader behavior, without persistence.
        path = folder_paths.get_full_path('vae', vae_name)
        file = CACHE.fingerprint(path) if path else None
        vae, = nodes.VAELoader().load_vae(vae_name)
        if file is not None:
            if signature(file['path']) != file['signature']:
                raise RuntimeError('VAE changed while loading; reload it')
            mark(vae, [file], {'loader': 'VAELoader'})
        return io.NodeOutput(vae)


class OpenJutsu3ClipProjApply(io.ComfyNode):
    @classmethod
    def define_schema(cls):
        return io.Schema(node_id='OpenJutsu3ClipProjApply', category='OpenJutsu V3', inputs=[
            io.Clip.Input('clip'), io.Combo.Input('projection', options=folder_paths.get_filename_list('clip_projections'))],
            outputs=[io.Clip.Output()])

    @classmethod
    def execute(cls, clip, projection):
        file = file_identity('clip_projections', projection)
        projected, = nodes.NODE_CLASS_MAPPINGS['ClipProjApply']().apply(clip, projection)
        source = getattr(clip, '_openjutsu3_source', None)
        if source is not None and signature(file['path']) == file['signature']:
            mark(projected, source['files'] + [file], {**source['settings'], 'projection': file['sha256']})
        return io.NodeOutput(projected)


class OpenJutsu3VideoTrackCached(SAM3_VideoTrack):
    @classmethod
    def reuse_tracking(cls, parameters, model, compute):
        key = cache_key('tracking', parameters, {'model': model})
        return CACHE.run('tracking', key, compute, NestedTensor)

    @classmethod
    def define_schema(cls):
        schema = super().define_schema()
        schema.node_id = 'OpenJutsu3VideoTrackCached'
        schema.display_name = 'OpenJutsu V3 SAM tracking cache'
        return schema

    @classmethod
    def execute(cls, images, model, initial_mask=None, conditioning=None, detection_threshold=0.5, max_objects=0, detect_interval=1):
        params = dict(images=images, initial_mask=initial_mask, conditioning=conditioning,
                      detection_threshold=detection_threshold, max_objects=max_objects, detect_interval=detect_interval)
        key = cache_key('tracking', params, {'model': model})
        return io.NodeOutput(*CACHE.run('tracking', key,
            lambda: SAM3_VideoTrack.execute(model=model, **params).args, NestedTensor))


class OpenJutsu3ReferenceCached(MiniMaxH3ReferenceToVideo):
    @classmethod
    def define_schema(cls):
        schema = super().define_schema()
        schema.node_id = 'OpenJutsu3ReferenceCached'
        schema.display_name = 'OpenJutsu V3 H3 conditioning cache'
        return schema

    @classmethod
    def execute(cls, clip, prompt, width, height, length, ref_image_size='match', vae=None, audio_vae=None,
                ref_images=None, ref_videos=None, ref_video_audios=None, ref_audios=None):
        params = dict(prompt=prompt, width=width, height=height, length=length, ref_image_size=ref_image_size,
                      ref_images=ref_images, ref_videos=ref_videos, ref_video_audios=ref_video_audios, ref_audios=ref_audios)
        key = cache_key('conditioning', params, {'clip': clip, 'vae': vae, 'audio_vae': audio_vae})
        if 'embedding:' in prompt.lower():
            key = None
        return io.NodeOutput(*CACHE.run('conditioning', key,
            lambda: MiniMaxH3ReferenceToVideo.execute(clip=clip, vae=vae, audio_vae=audio_vae, **params).args, NestedTensor))


class OpenJutsu3EditLatentCached(io.ComfyNode):
    @classmethod
    def define_schema(cls):
        return io.Schema(node_id='OpenJutsu3EditLatentCached', category='OpenJutsu V3', inputs=[
            io.Vae.Input('vae'), io.Image.Input('images'), io.Mask.Input('mask'),
            io.Int.Input('grow', default=16, min=0, max=256, step=1),
            io.Boolean.Input('keep_audio', default=True), io.Vae.Input('audio_vae', optional=True),
            io.Audio.Input('audio', optional=True),
            io.Float.Input('megapixels', default=0.98, min=0.0, max=16.0, step=0.01, optional=True)],
            outputs=[io.Latent.Output(), io.Int.Output(), io.Int.Output(), io.Int.Output()])

    @classmethod
    def execute(cls, vae, images, mask, grow=16, keep_audio=True, audio_vae=None, audio=None, megapixels=0.98):
        params = dict(images=images, mask=mask, grow=grow, keep_audio=keep_audio, audio=audio, megapixels=megapixels)
        key = cache_key('source', params, {'vae': vae, 'audio_vae': audio_vae})
        native = nodes.NODE_CLASS_MAPPINGS['MiniMaxH3FantasticVideoEditLatent']
        return io.NodeOutput(*CACHE.run('source', key,
            lambda: native().build(vae=vae, audio_vae=audio_vae, **params), NestedTensor))


class OpenJutsu3Extension(ComfyExtension):
    async def get_node_list(self):
        return [OpenJutsu3CheckpointLoader, OpenJutsu3CLIPLoader, OpenJutsu3VAELoader,
                OpenJutsu3ClipProjApply, OpenJutsu3VideoTrackCached,
                OpenJutsu3ReferenceCached, OpenJutsu3EditLatentCached]


async def comfy_entrypoint():
    return OpenJutsu3Extension()
