import importlib.util
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import json
import torch

spec = importlib.util.spec_from_file_location('v3_store', Path(__file__).with_name('store.py'))
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
Store, key_for = module.Store, module.key_for


class Nested:
    def __init__(self, tensors): self.tensors = tensors
    def unbind(self): return self.tensors


class StoreTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent)
        assert Path(self.temp.name).resolve().is_relative_to(Path(__file__).resolve().parent)
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.store = Store(self.root / 'cache', reserve=0)
        self.calls = 0

    def compute(self):
        self.calls += 1
        return ({'packed_masks': torch.tensor([[0, 255]], dtype=torch.uint8),
                 'scores': [0.3, 0.9], 'orig_size': (480, 864), 'n_frames': 2},)

    def test_hit_survives_a_new_store_instance_without_recompute(self):
        key = key_for({'pixels': torch.zeros(3, 5, 7, 3), 'threshold': 0.35})
        first = self.store.run('tracking', key, self.compute)
        second = Store(self.store.root, reserve=0).run('tracking', key, self.compute)
        self.assertEqual(self.calls, 1)
        self.assertEqual(second[0]['orig_size'], first[0]['orig_size'])
        self.assertTrue(torch.equal(first[0]['packed_masks'], second[0]['packed_masks']))

    def test_hash_distinguishes_types_shapes_and_parameters(self):
        values = [1, '1', True, 1.0, [1], (1,), {'x': 1}, torch.tensor(1),
                  torch.zeros(1, 2), torch.zeros(2, 1), torch.zeros(1, 2, dtype=torch.float64)]
        self.assertEqual(len({key_for(v) for v in values}), len(values))
        original = {'pixels': torch.zeros(2, 4, 4, 3), 'mask': torch.zeros(2, 4, 4),
                    'prompt': 'person', 'threshold': 0.35, 'interval': 1,
                    'model_sha': 'a', 'code_sha': 'a', 'size': [480, 864]}
        base = key_for(original)
        for name in original:
            changed = dict(original)
            if isinstance(changed[name], torch.Tensor): changed[name] = changed[name] + 1
            elif isinstance(changed[name], str): changed[name] += 'x'
            elif isinstance(changed[name], list): changed[name] = [736, 1248]
            else: changed[name] += 1
            self.assertNotEqual(base, key_for(changed), name)

    def test_noncontiguous_bfloat16_and_nested_outputs_roundtrip(self):
        video = torch.arange(120, dtype=torch.float32).reshape(2, 3, 4, 5).transpose(2, 3).to(torch.bfloat16)
        value = ({'samples': Nested([video, torch.zeros(1, 32, 2, 4)])}, 864, 480, 22)
        key = key_for('nested')
        self.store.run('source', key, lambda: value, Nested)
        result = self.store.run('source', key, lambda: self.fail('Cache miss'), Nested)
        self.assertIsInstance(result[0]['samples'], Nested)
        self.assertTrue(torch.equal(result[0]['samples'].tensors[0], video))
        self.assertEqual(result[1:], value[1:])

    def test_hash_reads_noncontiguous_video_in_small_chunks(self):
        video = torch.arange(24 * 512 * 512 * 3, dtype=torch.float32).reshape(24, 3, 512, 512).movedim(1, -1)
        self.assertFalse(video.is_contiguous())
        seen = []
        original = torch.Tensor.contiguous
        def record(tensor, *args, **kwargs):
            seen.append(tensor.numel() * tensor.element_size())
            return original(tensor, *args, **kwargs)
        with patch.object(torch.Tensor, 'contiguous', record):
            streamed = key_for(video)
        self.assertLessEqual(max(seen), 8 * 1024 ** 2)
        self.assertEqual(streamed, key_for(video.contiguous()))

    def test_corrupt_tensor_or_metadata_recomputes(self):
        key = key_for('corrupt')
        self.store.run('tracking', key, self.compute)
        next((self.store.root / 'tracking').glob('*.safetensors')).write_bytes(b'broken')
        self.store.run('tracking', key, self.compute)
        manifest = self.store.root / 'tracking' / (key + '.json')
        data = json.loads(manifest.read_text()); data['tree'] = ['tuple', []]
        manifest.write_text(json.dumps(data))
        self.store.run('tracking', key, self.compute)
        self.assertEqual(self.calls, 3)

    def test_untrusted_blob_path_is_not_read(self):
        key = key_for('traversal')
        self.store.run('tracking', key, self.compute)
        manifest = self.store.root / 'tracking' / (key + '.json')
        data = json.loads(manifest.read_text()); data['blob'] = '../outside.safetensors'
        manifest.write_text(json.dumps(data))
        self.assertIsNone(self.store.read('tracking', key))

    def test_invalid_safetensors_with_matching_digest_recomputes(self):
        key = key_for('invalid format')
        self.store.run('tracking', key, self.compute)
        manifest = self.store.root / 'tracking' / (key + '.json')
        data = json.loads(manifest.read_text())
        blob = manifest.parent / data['blob']; blob.write_bytes(b'not a safetensors file')
        data['sha256'] = module.digest_file(blob)
        manifest.write_text(json.dumps(data))
        self.store.run('tracking', key, self.compute)
        self.assertEqual(self.calls, 2)

    def test_write_failure_does_not_fail_native_result(self):
        with patch.object(self.store, 'write', side_effect=OSError('disk full')):
            result = self.store.run('tracking', key_for('full'), self.compute)
        self.assertEqual(result[0]['n_frames'], 2)

    def test_inference_failure_is_propagated_and_never_cached(self):
        with self.assertRaisesRegex(RuntimeError, 'CUDA'):
            self.store.run('source', key_for('failed'), lambda: (_ for _ in ()).throw(RuntimeError('CUDA error')))
        self.assertFalse(self.store.root.exists())

    def test_unknown_outputs_are_not_persisted(self):
        value = (object(),)
        self.assertIs(self.store.run('source', key_for('unknown'), lambda: value), value)
        self.assertFalse(self.store.root.exists())

    def test_budget_prunes_only_our_artifacts(self):
        self.store.budget = 1200
        unrelated = self.root / 'model.safetensors'; unrelated.write_bytes(b'model')
        for i in range(4):
            self.store.run('source', key_for(i), lambda: (torch.ones(180),))
        total = sum(p.stat().st_size for p in self.store.root.rglob('*.safetensors'))
        self.assertLessEqual(total, self.store.budget)
        self.assertEqual(unrelated.read_bytes(), b'model')

    def test_free_space_reserve_blocks_persistence(self):
        self.store.reserve = 10 ** 20
        self.store.run('tracking', key_for('reserve'), self.compute)
        self.assertFalse(list(self.store.root.rglob('*.safetensors')))

    def test_model_file_change_invalidates_fingerprint(self):
        model = self.root / 'weights'; model.write_bytes(b'first')
        before = self.store.fingerprint(model)
        model.write_bytes(b'second version')
        after = self.store.fingerprint(model)
        self.assertNotEqual(before['sha256'], after['sha256'])

    def test_kill_switch_and_missing_identity_bypass(self):
        self.store.run('tracking', None, self.compute)
        self.assertFalse(self.store.root.exists())
        self.store.root.mkdir(); (self.store.root / 'disabled').touch()
        self.store.run('tracking', key_for('disabled'), self.compute)
        self.assertEqual(self.calls, 2)
        self.assertFalse(list(self.store.root.rglob('*.safetensors')))


if __name__ == '__main__': unittest.main()
