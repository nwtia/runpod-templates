import logging
import torch
from comfy_api.latest import ComfyExtension, io
from comfy.ldm.sam3.tracker import unpack_masks
import comfy.model_management
from .blend import restore_frame, protected_core
from .foreground import OpenJutsuTrackForeground, OpenJutsuRegionTrackSlice


class OpenJutsuExcludeMouth(io.ComfyNode):
    @classmethod
    def define_schema(cls):
        return io.Schema(node_id='OpenJutsuExcludeMouth', category='OpenJutsu', inputs=[
            io.Mask.Input('editable_mask'), io.Custom('SAM3_TRACK_DATA').Input('track_data')],
            outputs=[io.Mask.Output()])

    @classmethod
    def execute(cls, editable_mask, track_data):
        packed = track_data['packed_masks']
        if packed is None:
            return io.NodeOutput(editable_mask)
        if editable_mask.shape[0] != int(track_data['n_frames']) or packed.shape[0] != editable_mask.shape[0]:
            raise ValueError('Region protection and edit mask must cover the same frames')
        result = torch.empty_like(editable_mask)
        for i in range(editable_mask.shape[0]):
            comfy.model_management.throw_exception_if_processing_interrupted()
            mask = unpack_masks(packed[i]).any(dim=0)
            core = protected_core(mask, editable_mask.shape[-2:], 4)[0, 0].to(editable_mask.device)
            result[i] = torch.where(core, 0, editable_mask[i])
        return io.NodeOutput(result)


class OpenJutsuPreserveMouth(io.ComfyNode):
    @classmethod
    def define_schema(cls):
        return io.Schema(node_id='OpenJutsuPreserveMouth', category='OpenJutsu', inputs=[
            io.Image.Input('source'), io.Image.Input('generated'),
            io.Custom('SAM3_TRACK_DATA').Input('track_data'),
            io.Int.Input('expand', default=3, min=0, max=16),
            io.Int.Input('feather', default=2, min=0, max=16)], outputs=[io.Image.Output()])

    @classmethod
    def execute(cls, source, generated, track_data, expand=3, feather=2):
        if source.shape != generated.shape or int(track_data['n_frames']) != generated.shape[0]:
            raise ValueError('Region protection needs frame-aligned source, output and tracking data')
        packed = track_data['packed_masks']
        if packed is None:
            logging.warning('[OpenJutsu] No tracked region was found; no source pixels were protected.')
            return io.NodeOutput(generated)
        if packed.shape[0] != generated.shape[0]:
            raise ValueError('Region tracking length does not match the video')
        result = torch.empty_like(generated)
        protected = 0
        for i in range(generated.shape[0]):
            comfy.model_management.throw_exception_if_processing_interrupted()
            mask = unpack_masks(packed[i]).any(dim=0)
            if mask.any():
                result[i] = restore_frame(source[i], generated[i], mask, expand, feather)
                protected += 1
            else:
                result[i] = generated[i]
        logging.info('[OpenJutsu] Kept tracked source pixels in %d/%d frames before video encoding.', protected, generated.shape[0])
        if protected < generated.shape[0]:
            logging.warning('[OpenJutsu] %d frames had no region mask; protection was not applied there.', generated.shape[0] - protected)
        return io.NodeOutput(result)


class OpenJutsuPreserveRegion(OpenJutsuPreserveMouth):
    @classmethod
    def define_schema(cls):
        schema = super().define_schema()
        schema.node_id = 'OpenJutsuPreserveRegion'
        schema.display_name = 'Keep tracked foreground pixels'
        return schema


class OpenJutsuExcludeRegion(OpenJutsuExcludeMouth):
    @classmethod
    def define_schema(cls):
        schema = super().define_schema()
        schema.node_id = 'OpenJutsuExcludeRegion'
        schema.display_name = 'Exclude tracked foreground from edit mask'
        return schema


class MouthExtension(ComfyExtension):
    async def get_node_list(self):
        return [OpenJutsuPreserveMouth, OpenJutsuExcludeMouth, OpenJutsuPreserveRegion, OpenJutsuExcludeRegion, OpenJutsuTrackForeground, OpenJutsuRegionTrackSlice]


async def comfy_entrypoint():
    return MouthExtension()
