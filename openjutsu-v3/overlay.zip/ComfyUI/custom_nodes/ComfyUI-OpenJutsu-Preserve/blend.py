"""Restore source pixels inside a tracked protection mask, with an outward-only feather."""
import torch
import torch.nn.functional as F


def protected_core(mask, shape, expand):
    core = F.interpolate(mask[None, None].float(), size=shape, mode='bilinear', align_corners=False) > 0.05
    if expand:
        core = F.max_pool2d(core.float(), expand * 2 + 1, stride=1, padding=expand) > 0
    return core


def restore_frame(source, generated, mask, expand=3, feather=2):
    if source.shape != generated.shape:
        raise ValueError('Source and generated frames must have identical dimensions')
    core = protected_core(mask, generated.shape[:2], expand)
    alpha = core.float()
    if feather:
        alpha = torch.maximum(alpha, F.avg_pool2d(alpha, feather * 2 + 1, stride=1, padding=feather))
    alpha = alpha[0, 0, :, :, None].to(device=generated.device, dtype=generated.dtype)
    source = source.to(device=generated.device, dtype=generated.dtype)
    mixed = generated * (1 - alpha) + source * alpha
    # Exact selection protects even when generated pixels contain NaNs underneath.
    return torch.where(core[0, 0, :, :, None].to(generated.device), source, mixed)
