"""Track a user-selected foreground object using native SAM; no H3/model patches."""
import hashlib
from pathlib import Path
import torch
import nodes
import comfy.model_management
from comfy_api.latest import io
from comfy_extras.nodes_sam3 import SAM3_Detect, SAM3_VideoTrack
from .geometry import parse_selection, cropped_box

ALGORITHM = hashlib.sha256(Path(__file__).read_bytes() + Path(__file__).with_name('geometry.py').read_bytes()).hexdigest()


def join_tracks(forward, backward, seed, count, height, width):
    front = forward['packed_masks']
    if front is None:
        raise ValueError('SAM lost the selected object. Select a clearer frame and a tighter box.')
    if seed:
        back = backward['packed_masks']
        if back is None:
            raise ValueError('SAM could not follow the object before the selected frame')
        packed = torch.cat([back[1:].flip(0), front], dim=0)
    else:
        packed = front
    if packed.shape[0] != count:
        raise ValueError('Object tracking returned an incomplete timeline')
    return {'packed_masks': packed, 'n_frames': count, 'orig_size': (height, width), 'scores': []}


class OpenJutsuTrackForeground(io.ComfyNode):
    @classmethod
    def define_schema(cls):
        return io.Schema(node_id='OpenJutsuTrackForeground', category='OpenJutsu', inputs=[
            io.Image.Input('images'), io.Model.Input('model'), io.String.Input('selection'),
            io.Int.Input('original_width', default=512, min=1),
            io.Int.Input('original_height', default=512, min=1)],
            outputs=[io.Custom('SAM3_TRACK_DATA').Output()])

    @classmethod
    def execute(cls, images, model, selection, original_width=512, original_height=512):
        box = parse_selection(selection)
        seed = box['frame']
        count, height, width = images.shape[:3]
        if seed >= count:
            raise ValueError('Select the protected object within the chosen video section')
        bbox = cropped_box(box, original_width, original_height, width, height)
        def compute():
            initial = SAM3_Detect.execute(model=model, image=images[seed:seed+1], bboxes=bbox,
                                         refine_iterations=2).args[0]
            if not torch.count_nonzero(initial).item():
                raise ValueError('SAM found no object in this box. Choose a clearer frame or a tighter box.')
            forward = SAM3_VideoTrack.execute(model=model, images=images[seed:], initial_mask=initial,
                                             max_objects=1).args[0]
            backward = None
            if seed:
                reverse_bytes = (seed + 1) * height * width * images.shape[-1] * images.element_size()
                free = comfy.model_management.get_free_memory(torch.device('cpu'))
                if reverse_bytes > free * 0.5:
                    raise RuntimeError('Not enough RAM to track backward; choose an earlier seed or a shorter section')
                reversed_images = images[:seed+1].flip(0)
                backward = SAM3_VideoTrack.execute(model=model, images=reversed_images, initial_mask=initial,
                                                  max_objects=1).args[0]
                del reversed_images
            return (join_tracks(forward, backward, seed, count, height, width),)
        cache = nodes.NODE_CLASS_MAPPINGS.get('OpenJutsu3VideoTrackCached')
        if cache is not None:
            values = cache.reuse_tracking({'images': images, 'selection': box,
                'original_size': [original_width, original_height], 'algorithm': ALGORITHM}, model, compute)
        else:
            values = compute()
        return io.NodeOutput(*values)


class OpenJutsuRegionTrackSlice(io.ComfyNode):
    @classmethod
    def define_schema(cls):
        return io.Schema(node_id='OpenJutsuRegionTrackSlice', category='OpenJutsu', inputs=[
            io.Custom('SAM3_TRACK_DATA').Input('track_data'), io.Custom('H3_CHAIN_STATE').Input('state')],
            outputs=[io.Custom('SAM3_TRACK_DATA').Output()])

    @classmethod
    def execute(cls, track_data, state):
        shot = state['plan']['shots'][int(state['index']) - 1]
        start, count = int(shot['generation_start_frame']), int(shot['raw_frames'])
        n = int(track_data['n_frames'])
        if n < 1 or start < 0 or count < 1:
            raise ValueError('Invalid protected-object timeline')
        packed = track_data['packed_masks']
        picks = [min(i, n - 1) for i in range(start, start + count)]
        return io.NodeOutput({**track_data, 'n_frames': count,
                              'packed_masks': packed[picks] if packed is not None else None})
