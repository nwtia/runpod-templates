import json
import math


def parse_selection(value):
    box = json.loads(value) if isinstance(value, str) else value
    if not isinstance(box, dict) or type(box.get('frame')) is not int or box['frame'] < 0:
        raise ValueError('Choose an object inside the selected video section')
    for k in ('x', 'y', 'width', 'height'):
        if type(box.get(k)) not in (int, float) or not math.isfinite(box[k]):
            raise ValueError('Object selection must contain finite coordinates')
    if not (0 <= box['x'] < 1 and 0 <= box['y'] < 1 and box['width'] > 0 and box['height'] > 0
            and box['x'] + box['width'] <= 1.000001 and box['y'] + box['height'] <= 1.000001):
        raise ValueError('Draw the object selection inside the video')
    return {k: box[k] for k in ('frame', 'x', 'y', 'width', 'height')}


def cropped_box(selection, original_width, original_height, width, height):
    scale = max(width / original_width, height / original_height)
    dx = (original_width * scale - width) / 2
    dy = (original_height * scale - height) / 2
    x1 = max(0, selection['x'] * original_width * scale - dx)
    y1 = max(0, selection['y'] * original_height * scale - dy)
    x2 = min(width, (selection['x'] + selection['width']) * original_width * scale - dx)
    y2 = min(height, (selection['y'] + selection['height']) * original_height * scale - dy)
    if x2 <= x1 or y2 <= y1:
        raise ValueError('Protected object lies outside the selected crop')
    return {'x': x1, 'y': y1, 'width': x2 - x1, 'height': y2 - y1}
